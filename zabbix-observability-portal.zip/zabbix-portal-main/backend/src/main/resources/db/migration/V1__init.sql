-- ── Áreas ────────────────────────────────────────────────────────────────
-- filter_type decide se "quais hosts/templates pertencem à área" é resolvido
-- por grupo (host group / template group) ou por tag (ex: portal:dba).
-- Essa escolha é feita por quem gerencia o portal, na tela oculta.
CREATE TABLE areas (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  name                VARCHAR(120) NOT NULL UNIQUE,
  description         VARCHAR(500),
  color               VARCHAR(16)  NOT NULL DEFAULT '#3B82F6',
  filter_type         VARCHAR(20)  NOT NULL DEFAULT 'HOST_GROUP', -- HOST_GROUP | TAG
  -- HOST_GROUP: nomes de grupos (host group / template group), separados por vírgula
  group_names         VARCHAR(1000),
  -- TAG: chave e valor da tag (ex: tag_key='portal', tag_value='dba')
  tag_key             VARCHAR(120),
  tag_value           VARCHAR(120),
  zabbix_connection_id BIGINT,
  created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ── Conexões Zabbix (multi-instância, igual ao portal atual) ───────────────
CREATE TABLE zabbix_connections (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  url         VARCHAR(500) NOT NULL,
  auth_type   VARCHAR(20)  NOT NULL DEFAULT 'TOKEN', -- TOKEN | USERPASS
  token       VARCHAR(500),
  username    VARCHAR(120),
  password    VARCHAR(500),
  active      BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE areas ADD CONSTRAINT fk_areas_connection
  FOREIGN KEY (zabbix_connection_id) REFERENCES zabbix_connections(id);

-- ── Usuários locais (fallback quando o Blackbird está fora do ar) ──────────
CREATE TABLE portal_users (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  username        VARCHAR(120) NOT NULL UNIQUE,
  password_hash   VARCHAR(200) NOT NULL,
  full_name       VARCHAR(200) NOT NULL,
  email           VARCHAR(200),
  active          BOOLEAN NOT NULL DEFAULT TRUE,
  last_login      TIMESTAMP,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ── Gestores do portal ──────────────────────────────────────────────────
-- Quem está nessa lista enxerga a tela oculta de gestão de áreas,
-- independente de ter entrado via Blackbird ou via login local.
CREATE TABLE portal_managers (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  username    VARCHAR(120) NOT NULL UNIQUE,
  added_by    VARCHAR(120),
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ── Log de acesso (login/logout) ────────────────────────────────────────
CREATE TABLE access_logs (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  username    VARCHAR(120),
  auth_source VARCHAR(20), -- BLACKBIRD | LOCAL
  action      VARCHAR(40) NOT NULL,
  ip          VARCHAR(64),
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ── Seed: duas áreas iniciais pedidas (Banco de Dados e Network) ──────────
INSERT INTO areas (name, description, color, filter_type, group_names, tag_key, tag_value)
VALUES ('Banco de Dados', 'Oracle, SQL Server, PostgreSQL, MongoDB', '#F59E0B', 'HOST_GROUP', 'Banco de Dados', NULL, NULL);

INSERT INTO areas (name, description, color, filter_type, group_names, tag_key, tag_value)
VALUES ('Network', 'Switches, Firewalls, Roteadores', '#10B981', 'TAG', NULL, 'portal', 'network');

-- ── Seed: usuário local de fallback (senha deve ser trocada em produção) ──
-- Hash bcrypt de 'Admin@2024!' (custo 12) — igual ao usuário padrão do portal atual.
INSERT INTO portal_users (username, password_hash, full_name, email)
VALUES ('admin', '$2b$12$8EhKzrjmnzEKXhWYOwqXougY3EgzvvR/jQ2OUKawJ6fh21kHprT92', 'Administrador do Portal', 'admin@pan.com.br');

INSERT INTO portal_managers (username, added_by) VALUES ('admin', 'seed');
