package com.pan.observability.auth.dto;

import com.pan.observability.auth.PortalManager;

public record PortalManagerDto(Long id, String username, String addedBy) {
  public static PortalManagerDto from(PortalManager m) {
    return new PortalManagerDto(m.getId(), m.getUsername(), m.getAddedBy());
  }
}
