package com.pan.observability.auth;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PortalUserRepository extends JpaRepository<PortalUser, Long> {
  Optional<PortalUser> findByUsernameIgnoreCaseAndActiveTrue(String username);
}
