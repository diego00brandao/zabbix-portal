package com.pan.observability.itemtrigger;

import com.pan.observability.area.AreaZabbixContext;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ItemTriggerController {

  private final AreaZabbixContext areaZabbixContext;
  private final ItemTriggerService itemTriggerService;

  public ItemTriggerController(AreaZabbixContext areaZabbixContext, ItemTriggerService itemTriggerService) {
    this.areaZabbixContext = areaZabbixContext;
    this.itemTriggerService = itemTriggerService;
  }

  @GetMapping("/items")
  public List<Map<String, Object>> items(@RequestHeader(value = "X-Area-Id", required = false) Long areaId) {
    return itemTriggerService.items(areaZabbixContext.resolve(areaId));
  }

  @GetMapping("/triggers")
  public List<Map<String, Object>> triggers(@RequestHeader(value = "X-Area-Id", required = false) Long areaId) {
    return itemTriggerService.triggers(areaZabbixContext.resolve(areaId));
  }
}
