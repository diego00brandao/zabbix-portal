package com.pan.observability.auth.dto;

public record LoginResponse(String token, UserDto user) {}
