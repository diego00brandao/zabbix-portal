package com.pan.observability.area;

import com.pan.observability.area.dto.AreaPublicDto;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Endpoint público (qualquer usuário autenticado) usado pela tela
 * "Selecionar Área" — só devolve id/nome/descrição/cor, nunca a condição
 * (grupo/tag) usada para filtrar os dados do Zabbix.
 */
@RestController
@RequestMapping("/api/areas")
public class AreaController {

  private final AreaService areaService;

  public AreaController(AreaService areaService) {
    this.areaService = areaService;
  }

  @GetMapping
  public List<AreaPublicDto> list() {
    return areaService.listAll().stream().map(AreaPublicDto::from).toList();
  }
}
