package com.pan.observability.auth;

import com.pan.observability.common.ApiException;
import java.time.LocalDateTime;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * Login local do portal — é o fallback usado quando o Blackbird está fora
 * do ar ou ainda não está configurado (ver BlackbirdAuthService).
 */
@Service
public class LocalAuthService {

  private final PortalUserRepository users;
  private final PasswordEncoder passwordEncoder;
  private final ManagerService managerService;
  private final PortalAuthProperties properties;

  public LocalAuthService(PortalUserRepository users, PasswordEncoder passwordEncoder,
                           ManagerService managerService, PortalAuthProperties properties) {
    this.users = users;
    this.passwordEncoder = passwordEncoder;
    this.managerService = managerService;
    this.properties = properties;
  }

  public AuthenticatedUser authenticate(String username, String password) {
    if (!properties.getAuth().getLocal().isEnabled()) {
      throw ApiException.forbidden("Login local desabilitado");
    }
    if (username == null || password == null || username.isBlank() || password.isBlank()) {
      throw ApiException.badRequest("Usuário e senha são obrigatórios");
    }
    PortalUser user = users.findByUsernameIgnoreCaseAndActiveTrue(username.trim())
        .orElseThrow(() -> ApiException.unauthorized("Credenciais inválidas"));
    if (!passwordEncoder.matches(password, user.getPasswordHash())) {
      throw ApiException.unauthorized("Credenciais inválidas");
    }
    user.setLastLogin(LocalDateTime.now());
    users.save(user);
    return new AuthenticatedUser(
        user.getUsername(), user.getFullName(), user.getEmail(),
        AuthSource.LOCAL, managerService.isManager(user.getUsername()));
  }
}
