package com.pan.observability.auth;

import com.pan.observability.common.ApiException;
import org.springframework.stereotype.Component;

/** Usado pelos controllers das telas ocultas (gestão de áreas/conexões/gestores). */
@Component
public class ManagerGuard {
  public void require(AuthenticatedUser user) {
    if (user == null || !user.portalManager()) {
      throw ApiException.forbidden("Acesso restrito a quem gerencia o portal");
    }
  }
}
