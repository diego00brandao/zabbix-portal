package com.pan.observability.area.dto;

import com.pan.observability.area.FilterType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/**
 * Corpo do POST/PUT da tela de gestão de áreas. {@code filterType} é quem
 * escolhe (o portal manager) se a condição é por grupo ou por tag — nunca
 * decidido pelo código.
 */
public record AreaUpsertRequest(
    @NotBlank String name,
    String description,
    String color,
    @NotNull FilterType filterType,
    String groupNames,
    String tagKey,
    String tagValue,
    Long zabbixConnectionId
) {}
