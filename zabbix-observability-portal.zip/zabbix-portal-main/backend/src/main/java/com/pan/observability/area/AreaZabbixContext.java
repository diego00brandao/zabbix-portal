package com.pan.observability.area;

import com.pan.observability.zabbix.ZabbixApiClient;
import com.pan.observability.zabbix.ZabbixConnection;
import com.pan.observability.zabbix.ZabbixConnectionResolver;
import org.springframework.stereotype.Component;

/**
 * Resolve, a partir do header X-Area-Id, tudo que os endpoints de dados
 * (Servidores/Manutenções/Itens & Triggers) precisam: a área escolhida pelo
 * usuário, a conexão Zabbix dela e o escopo (grupo ou tag) já traduzido.
 */
@Component
public class AreaZabbixContext {

  private final AreaService areaService;
  private final ZabbixConnectionResolver connectionResolver;
  private final AreaScopeResolver scopeResolver;
  private final ZabbixApiClient client;

  public AreaZabbixContext(AreaService areaService, ZabbixConnectionResolver connectionResolver,
                            AreaScopeResolver scopeResolver, ZabbixApiClient client) {
    this.areaService = areaService;
    this.connectionResolver = connectionResolver;
    this.scopeResolver = scopeResolver;
    this.client = client;
  }

  public record Context(Area area, ZabbixConnection connection, ZabbixScope scope, ZabbixApiClient client) {}

  public Context resolve(Long areaId) {
    Area area = areaService.requireSelectedArea(areaId);
    ZabbixConnection connection = connectionResolver.resolve(area.getZabbixConnectionId());
    ZabbixScope scope = scopeResolver.resolve(area, client, connection);
    return new Context(area, connection, scope, client);
  }
}
