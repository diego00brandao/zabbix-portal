package com.pan.observability.auth;

import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;

/**
 * Quem é "gestor do portal" (enxerga a tela oculta de gestão de áreas).
 * Bootstrap via {@code portal.managers.seed-usernames}; depois disso a
 * lista é mantida na tabela portal_managers (editável pela própria tela).
 */
@Service
public class ManagerService implements ApplicationRunner {

  private static final Logger log = LoggerFactory.getLogger(ManagerService.class);

  private final PortalManagerRepository repository;
  private final PortalAuthProperties properties;

  public ManagerService(PortalManagerRepository repository, PortalAuthProperties properties) {
    this.repository = repository;
    this.properties = properties;
  }

  @Override
  public void run(ApplicationArguments args) {
    String seed = properties.getManagers().getSeedUsernames();
    if (seed == null || seed.isBlank()) return;
    Arrays.stream(seed.split(","))
        .map(String::trim)
        .filter(s -> !s.isBlank())
        .map(String::toLowerCase)
        .forEach(username -> {
          if (!repository.existsByUsernameIgnoreCase(username)) {
            PortalManager m = new PortalManager();
            m.setUsername(username);
            m.setAddedBy("seed");
            repository.save(m);
            log.info("Gestor do portal (seed): {}", username);
          }
        });
  }

  public boolean isManager(String username) {
    if (username == null) return false;
    return repository.existsByUsernameIgnoreCase(username);
  }
}
