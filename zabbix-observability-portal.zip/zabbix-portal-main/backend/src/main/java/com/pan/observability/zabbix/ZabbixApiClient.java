package com.pan.observability.zabbix;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Cliente JSON-RPC para a API do Zabbix. Equivalente ao antigo
 * backend/services/zabbix.js#call — cada ZabbixConnection guarda sua própria
 * sessão (token estático ou login usuário/senha, cacheado em memória).
 */
@Component
public class ZabbixApiClient {

  private static final Logger log = LoggerFactory.getLogger(ZabbixApiClient.class);

  private final HttpClient httpClient;
  private final ObjectMapper mapper = new ObjectMapper();
  private final ZabbixProperties properties;
  private final Map<Long, String> sessionTokens = new ConcurrentHashMap<>();
  private final AtomicInteger requestId = new AtomicInteger(1);

  public ZabbixApiClient(ZabbixProperties properties) {
    this.properties = properties;
    this.httpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofMillis(properties.getRequestTimeoutMs()))
        .build();
  }

  public JsonNode call(ZabbixConnection connection, String method, Map<String, Object> params) {
    String auth = requiresAuth(method) ? resolveAuthToken(connection) : null;
    return doCall(connection, method, params, auth, true);
  }

  @SuppressWarnings("unchecked")
  public List<Map<String, Object>> callList(ZabbixConnection connection, String method, Map<String, Object> params) {
    JsonNode result = call(connection, method, params);
    if (result == null || result.isNull()) return new java.util.ArrayList<>();
    List<Map<String, Object>> converted = mapper.convertValue(result, List.class);
    return converted != null ? converted : new java.util.ArrayList<>();
  }

  private JsonNode doCall(ZabbixConnection connection, String method, Map<String, Object> params,
                           String auth, boolean retryOnAuthError) {
    try {
      Map<String, Object> body = new java.util.LinkedHashMap<>();
      body.put("jsonrpc", "2.0");
      body.put("method", method);
      body.put("params", params == null ? Map.of() : params);
      body.put("id", requestId.getAndIncrement());
      if (auth != null) body.put("auth", auth);

      HttpRequest request = HttpRequest.newBuilder()
          .uri(URI.create(connection.getUrl()))
          .timeout(Duration.ofMillis(properties.getRequestTimeoutMs()))
          .header("Content-Type", "application/json-rpc")
          .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
          .build();

      HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
      JsonNode json = mapper.readTree(response.body());

      if (json.has("error")) {
        String message = json.at("/error/data").isMissingNode()
            ? json.at("/error/message").asText("Erro desconhecido do Zabbix")
            : json.at("/error/data").asText();
        // Sessão expirada: tenta reautenticar uma vez (só faz sentido para USERPASS).
        boolean sessionError = message.toLowerCase().contains("session terminated")
            || message.toLowerCase().contains("not authorised");
        if (sessionError && retryOnAuthError && connection.getAuthType() == ZabbixAuthType.USERPASS) {
          sessionTokens.remove(connection.getId());
          String freshAuth = resolveAuthToken(connection);
          return doCall(connection, method, params, freshAuth, false);
        }
        throw new ZabbixRpcException("Zabbix (" + connection.getName() + "): " + message);
      }
      return json.get("result");
    } catch (ZabbixRpcException e) {
      throw e;
    } catch (Exception e) {
      log.error("Falha ao chamar Zabbix [{}] método {}", connection.getName(), method, e);
      throw new ZabbixRpcException("Falha ao comunicar com o Zabbix (" + connection.getName() + "): " + e.getMessage(), e);
    }
  }

  private boolean requiresAuth(String method) {
    return !method.equals("apiinfo.version") && !method.equals("user.login");
  }

  private String resolveAuthToken(ZabbixConnection connection) {
    if (connection.getAuthType() == ZabbixAuthType.TOKEN) {
      if (connection.getToken() == null || connection.getToken().isBlank()) {
        throw new ZabbixRpcException("Conexão Zabbix '" + connection.getName() + "' sem token configurado");
      }
      return connection.getToken();
    }
    return sessionTokens.computeIfAbsent(connection.getId(), id -> login(connection));
  }

  private String login(ZabbixConnection connection) {
    Map<String, Object> params = Map.of(
        "username", connection.getUsername(),
        "password", connection.getPassword());
    JsonNode result = doCall(connection, "user.login", params, null, false);
    if (result == null || !result.isTextual()) {
      throw new ZabbixRpcException("Falha ao autenticar na conexão Zabbix '" + connection.getName() + "'");
    }
    return result.asText();
  }

  /** Usado pela tela de gestão para validar uma conexão antes de salvar. */
  public String testConnection(ZabbixConnection connection) {
    JsonNode version = call(connection, "apiinfo.version", Map.of());
    call(connection, "host.get", Map.of("output", "count", "countOutput", true));
    return version.asText();
  }
}
