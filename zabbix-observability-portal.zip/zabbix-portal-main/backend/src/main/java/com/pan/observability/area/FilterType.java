package com.pan.observability.area;

/**
 * Como a área decide "quais hosts/templates são meus" no Zabbix.
 * Escolhido por quem gerencia o portal, por área — nunca fixo no código
 * (ver AreaScopeResolver).
 */
public enum FilterType {
  /** Por host group / template group (ex: grupo "Banco de Dados"). */
  HOST_GROUP,
  /** Por tag no host e no template (ex: portal:dba). */
  TAG
}
