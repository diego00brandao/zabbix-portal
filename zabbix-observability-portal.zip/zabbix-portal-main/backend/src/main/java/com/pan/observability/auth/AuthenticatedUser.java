package com.pan.observability.auth;

/**
 * Identidade resolvida para a requisição atual — vem tanto do login local
 * quanto do login via Blackbird. É isso que vai dentro do JWT do portal e é
 * o que os controllers recebem via {@code @AuthenticationPrincipal}.
 */
public record AuthenticatedUser(
    String username,
    String fullName,
    String email,
    AuthSource authSource,
    boolean portalManager
) {}
