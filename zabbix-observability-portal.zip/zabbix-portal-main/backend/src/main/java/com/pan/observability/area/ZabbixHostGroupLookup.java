package com.pan.observability.area;

import com.fasterxml.jackson.databind.JsonNode;
import com.pan.observability.zabbix.ZabbixApiClient;
import com.pan.observability.zabbix.ZabbixConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

/**
 * Resolve nomes de host group para group ids, com cache — grupo isolado num
 * bean próprio (em vez de método privado dentro de AreaScopeResolver) porque
 * @Cacheable só funciona através do proxy do Spring, e chamada dentro da
 * mesma classe (self-invocation) não passa pelo proxy.
 */
@Component
public class ZabbixHostGroupLookup {

  private static final Logger log = LoggerFactory.getLogger(ZabbixHostGroupLookup.class);

  @Cacheable(cacheNames = "zabbix-hostgroups", key = "#connection.id + ':' + #names")
  public List<String> resolveGroupIds(ZabbixApiClient client, ZabbixConnection connection, List<String> names) {
    JsonNode result = client.call(connection, "hostgroup.get", Map.of(
        "output", List.of("groupid", "name"),
        "filter", Map.of("name", names)));
    List<String> ids = new ArrayList<>();
    if (result != null) result.forEach(n -> ids.add(n.get("groupid").asText()));
    if (ids.size() < names.size()) {
      log.warn("Área com filtro por grupo: {} grupo(s) configurado(s) não foram encontrados no Zabbix ({})",
          names.size() - ids.size(), connection.getName());
    }
    return ids;
  }
}
