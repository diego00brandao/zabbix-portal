package com.pan.observability.auth.dto;

import com.pan.observability.auth.AuthenticatedUser;

public record UserDto(String username, String fullName, String email, String authSource, boolean portalManager) {
  public static UserDto from(AuthenticatedUser u) {
    return new UserDto(u.username(), u.fullName(), u.email(), u.authSource().name(), u.portalManager());
  }
}
