package com.pan.observability.server;

import com.pan.observability.area.AreaZabbixContext;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Tela "Servidores": lista + detalhe, sempre filtrados pela área selecionada (header X-Area-Id). */
@RestController
@RequestMapping("/api/servers")
public class ServerController {

  private final AreaZabbixContext areaZabbixContext;
  private final ServerService serverService;

  public ServerController(AreaZabbixContext areaZabbixContext, ServerService serverService) {
    this.areaZabbixContext = areaZabbixContext;
    this.serverService = serverService;
  }

  @GetMapping
  public List<Map<String, Object>> list(@RequestHeader(value = "X-Area-Id", required = false) Long areaId) {
    return serverService.listServers(areaZabbixContext.resolve(areaId));
  }

  @GetMapping("/{hostId}")
  public Map<String, Object> detail(@RequestHeader(value = "X-Area-Id", required = false) Long areaId,
                                     @PathVariable String hostId) {
    return serverService.serverDetail(areaZabbixContext.resolve(areaId), hostId);
  }
}
