package com.pan.observability.zabbix.dto;

import com.pan.observability.zabbix.ZabbixAuthType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record ZabbixConnectionUpsertRequest(
    @NotBlank String name,
    @NotBlank String url,
    @NotNull ZabbixAuthType authType,
    String token,
    String username,
    String password
) {}
