package com.pan.observability.itemtrigger;

import com.pan.observability.area.AreaZabbixContext.Context;
import com.pan.observability.zabbix.ZabbixItemFormatting;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

/**
 * Tela "Itens & Triggers" — igual ao antigo ItemsTriggers.jsx (viewer): o
 * escopo é sempre por TEMPLATE (a área define quais templates são dela, via
 * grupo ou tag — ver AreaScopeResolver), e o front agrupa por template e
 * vincula item→trigger pela chave.
 */
@Service
public class ItemTriggerService {

  private static final List<String> ITEM_OUTPUT = List.of(
      "itemid", "name", "key_", "type", "value_type", "delay", "history",
      "trends", "units", "params", "lastvalue", "lastclock", "status", "description", "error", "master_itemid");

  private static final List<String> TRIGGER_OUTPUT = List.of(
      "triggerid", "description", "priority", "status", "expression", "value", "lastchange", "comments");

  public List<Map<String, Object>> items(Context ctx) {
    List<String> templateIds = resolveTemplateIds(ctx);
    if (templateIds.isEmpty()) return List.of();

    Map<String, Object> params = new LinkedHashMap<>();
    params.put("output", ITEM_OUTPUT);
    params.put("templateids", templateIds);
    params.put("selectHosts", List.of("hostid", "host", "name"));
    params.put("webitems", true);
    params.put("limit", 5000);
    List<Map<String, Object>> items = new ArrayList<>(ctx.client().callList(ctx.connection(), "item.get", params));

    Map<String, Object> protoParams = new LinkedHashMap<>(params);
    protoParams.remove("webitems");
    List<Map<String, Object>> prototypes = ctx.client().callList(ctx.connection(), "itemprototype.get", protoParams);
    for (Map<String, Object> p : prototypes) p.put("isPrototype", true);
    items.addAll(prototypes);

    for (Map<String, Object> item : items) {
      String type = String.valueOf(item.get("type"));
      String key = String.valueOf(item.getOrDefault("key_", ""));
      item.put("isQuery", ZabbixItemFormatting.isQueryItem(type, key));
      item.put("typeLabel", ZabbixItemFormatting.typeLabel(type));
      item.put("delayFormatted", ZabbixItemFormatting.formatDelay(String.valueOf(item.get("delay"))));
    }
    return items;
  }

  public List<Map<String, Object>> triggers(Context ctx) {
    List<String> templateIds = resolveTemplateIds(ctx);
    if (templateIds.isEmpty()) return List.of();

    Map<String, Object> params = new LinkedHashMap<>();
    params.put("output", TRIGGER_OUTPUT);
    params.put("templateids", templateIds);
    params.put("selectHosts", List.of("hostid", "host", "name"));
    params.put("expandExpression", true);
    params.put("sortfield", "priority");
    params.put("sortorder", "DESC");
    List<Map<String, Object>> triggers = new ArrayList<>(ctx.client().callList(ctx.connection(), "trigger.get", params));

    List<Map<String, Object>> prototypes = ctx.client().callList(ctx.connection(), "triggerprototype.get", params);
    for (Map<String, Object> p : prototypes) p.put("isPrototype", true);
    triggers.addAll(prototypes);

    return triggers;
  }

  /** Resolve, para a área atual (grupo OU tag), a lista de templateids que pertencem a ela. */
  private List<String> resolveTemplateIds(Context ctx) {
    if (ctx.scope().isEmpty()) return List.of();
    Map<String, Object> params = new LinkedHashMap<>();
    params.put("output", List.of("templateid", "host", "name"));
    ctx.scope().applyToTemplateParams(params);
    List<Map<String, Object>> templates = ctx.client().callList(ctx.connection(), "template.get", params);
    return templates.stream().map(t -> String.valueOf(t.get("templateid"))).toList();
  }
}
