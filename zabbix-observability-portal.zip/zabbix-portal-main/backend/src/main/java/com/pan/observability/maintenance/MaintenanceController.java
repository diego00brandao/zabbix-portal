package com.pan.observability.maintenance;

import com.pan.observability.area.AreaZabbixContext;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/maintenances")
public class MaintenanceController {

  private final AreaZabbixContext areaZabbixContext;
  private final MaintenanceService maintenanceService;

  public MaintenanceController(AreaZabbixContext areaZabbixContext, MaintenanceService maintenanceService) {
    this.areaZabbixContext = areaZabbixContext;
    this.maintenanceService = maintenanceService;
  }

  @GetMapping
  public List<Map<String, Object>> list(@RequestHeader(value = "X-Area-Id", required = false) Long areaId) {
    return maintenanceService.list(areaZabbixContext.resolve(areaId));
  }
}
