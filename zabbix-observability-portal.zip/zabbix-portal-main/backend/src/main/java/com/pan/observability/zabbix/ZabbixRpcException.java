package com.pan.observability.zabbix;

public class ZabbixRpcException extends RuntimeException {
  public ZabbixRpcException(String message) {
    super(message);
  }

  public ZabbixRpcException(String message, Throwable cause) {
    super(message, cause);
  }
}
