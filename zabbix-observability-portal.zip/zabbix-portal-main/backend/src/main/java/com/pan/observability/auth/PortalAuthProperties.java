package com.pan.observability.auth;

import org.springframework.boot.context.properties.ConfigurationProperties;

/** Mapeia o bloco `portal.*` do application.yml. */
@ConfigurationProperties(prefix = "portal")
public class PortalAuthProperties {

  private final Jwt jwt = new Jwt();
  private final Managers managers = new Managers();
  private final Auth auth = new Auth();

  public Jwt getJwt() { return jwt; }
  public Managers getManagers() { return managers; }
  public Auth getAuth() { return auth; }

  public static class Jwt {
    private String secret;
    private int expirationMinutes = 480;
    public String getSecret() { return secret; }
    public void setSecret(String secret) { this.secret = secret; }
    public int getExpirationMinutes() { return expirationMinutes; }
    public void setExpirationMinutes(int expirationMinutes) { this.expirationMinutes = expirationMinutes; }
  }

  public static class Managers {
    /** Usernames (Blackbird ou locais) que já nascem com acesso à gestão de áreas. */
    private String seedUsernames = "";
    public String getSeedUsernames() { return seedUsernames; }
    public void setSeedUsernames(String seedUsernames) { this.seedUsernames = seedUsernames; }
  }

  public static class Auth {
    private final Blackbird blackbird = new Blackbird();
    private final Local local = new Local();
    public Blackbird getBlackbird() { return blackbird; }
    public Local getLocal() { return local; }
  }

  public static class Blackbird {
    private boolean enabled = false;
    private String sharedSecret;
    private String jwksUri;
    private String expectedIssuer = "blackbird";
    private String usernameClaim = "preferred_username";
    private String fullnameClaim = "name";
    private String emailClaim = "email";

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getSharedSecret() { return sharedSecret; }
    public void setSharedSecret(String sharedSecret) { this.sharedSecret = sharedSecret; }
    public String getJwksUri() { return jwksUri; }
    public void setJwksUri(String jwksUri) { this.jwksUri = jwksUri; }
    public String getExpectedIssuer() { return expectedIssuer; }
    public void setExpectedIssuer(String expectedIssuer) { this.expectedIssuer = expectedIssuer; }
    public String getUsernameClaim() { return usernameClaim; }
    public void setUsernameClaim(String usernameClaim) { this.usernameClaim = usernameClaim; }
    public String getFullnameClaim() { return fullnameClaim; }
    public void setFullnameClaim(String fullnameClaim) { this.fullnameClaim = fullnameClaim; }
    public String getEmailClaim() { return emailClaim; }
    public void setEmailClaim(String emailClaim) { this.emailClaim = emailClaim; }
  }

  public static class Local {
    private boolean enabled = true;
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
  }
}
