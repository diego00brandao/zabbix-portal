package com.pan.observability.zabbix;

import com.pan.observability.auth.AuthenticatedUser;
import com.pan.observability.auth.ManagerGuard;
import com.pan.observability.common.ApiException;
import com.pan.observability.zabbix.dto.ZabbixConnectionDto;
import com.pan.observability.zabbix.dto.ZabbixConnectionUpsertRequest;
import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Também faz parte da tela oculta de gestão (não aparece em nenhum menu do usuário final). */
@RestController
@RequestMapping("/api/manage/zabbix-connections")
public class ZabbixConnectionAdminController {

  private final ZabbixConnectionRepository repository;
  private final ZabbixApiClient client;
  private final ManagerGuard managerGuard;

  public ZabbixConnectionAdminController(ZabbixConnectionRepository repository, ZabbixApiClient client,
                                          ManagerGuard managerGuard) {
    this.repository = repository;
    this.client = client;
    this.managerGuard = managerGuard;
  }

  @GetMapping
  public List<ZabbixConnectionDto> list(@AuthenticationPrincipal AuthenticatedUser user) {
    managerGuard.require(user);
    return repository.findAll().stream().map(ZabbixConnectionDto::from).toList();
  }

  @PostMapping
  public ZabbixConnectionDto create(@AuthenticationPrincipal AuthenticatedUser user,
                                     @Valid @RequestBody ZabbixConnectionUpsertRequest req) {
    managerGuard.require(user);
    validate(req);
    ZabbixConnection conn = new ZabbixConnection();
    apply(conn, req);
    return ZabbixConnectionDto.from(repository.save(conn));
  }

  @PutMapping("/{id}")
  public ZabbixConnectionDto update(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long id,
                                     @Valid @RequestBody ZabbixConnectionUpsertRequest req) {
    managerGuard.require(user);
    validate(req);
    ZabbixConnection conn = repository.findById(id).orElseThrow(() -> ApiException.notFound("Conexão não encontrada"));
    apply(conn, req);
    conn.setUpdatedAt(LocalDateTime.now());
    return ZabbixConnectionDto.from(repository.save(conn));
  }

  @DeleteMapping("/{id}")
  public Map<String, Boolean> delete(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long id) {
    managerGuard.require(user);
    ZabbixConnection conn = repository.findById(id).orElseThrow(() -> ApiException.notFound("Conexão não encontrada"));
    if (conn.isActive()) throw ApiException.badRequest("Não é possível excluir a conexão ativa");
    repository.deleteById(id);
    return Map.of("success", true);
  }

  @PostMapping("/{id}/activate")
  public Map<String, Boolean> activate(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long id) {
    managerGuard.require(user);
    ZabbixConnection target = repository.findById(id).orElseThrow(() -> ApiException.notFound("Conexão não encontrada"));
    repository.findAll().forEach(c -> { c.setActive(c.getId().equals(id)); repository.save(c); });
    return Map.of("success", true);
  }

  @PostMapping("/test")
  public Map<String, Object> test(@AuthenticationPrincipal AuthenticatedUser user,
                                   @Valid @RequestBody ZabbixConnectionUpsertRequest req) {
    managerGuard.require(user);
    ZabbixConnection probe = new ZabbixConnection();
    probe.setId(-1L);
    apply(probe, req);
    try {
      String version = client.testConnection(probe);
      return Map.of("success", true, "version", version);
    } catch (Exception e) {
      return Map.of("success", false, "error", e.getMessage());
    }
  }

  private void validate(ZabbixConnectionUpsertRequest req) {
    if (req.authType() == ZabbixAuthType.TOKEN && (req.token() == null || req.token().isBlank())) {
      throw ApiException.badRequest("Token é obrigatório para autenticação por token");
    }
    if (req.authType() == ZabbixAuthType.USERPASS
        && (req.username() == null || req.username().isBlank() || req.password() == null || req.password().isBlank())) {
      throw ApiException.badRequest("Usuário e senha são obrigatórios para autenticação por usuário/senha");
    }
  }

  private void apply(ZabbixConnection conn, ZabbixConnectionUpsertRequest req) {
    conn.setName(req.name());
    conn.setUrl(req.url().trim());
    conn.setAuthType(req.authType());
    conn.setToken(req.token());
    conn.setUsername(req.username());
    conn.setPassword(req.password());
  }
}
