package com.pan.observability.area;

import com.fasterxml.jackson.databind.JsonNode;
import com.pan.observability.zabbix.ZabbixApiClient;
import com.pan.observability.zabbix.ZabbixConnection;
import com.pan.observability.zabbix.ZabbixProperties;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Transforma a condição de uma área (grupo OU tag — escolhida por quem
 * gerencia o portal, ver Area#filterType) nos parâmetros que a API do
 * Zabbix entende. É o substituto direto do antigo
 * backend/routes/zabbix.js#getGroupIds, só que agora plugável.
 */
@Service
public class AreaScopeResolver {

  private static final Logger log = LoggerFactory.getLogger(AreaScopeResolver.class);

  /**
   * Operador de igualdade exata para o filtro "tags" da API do Zabbix
   * (TAG_OPERATOR_EQUAL). Confirmar contra a documentação da versão exata
   * do Zabbix em produção antes do primeiro deploy — se a instância usar
   * outro código para "igual", ajuste só esta constante.
   */
  private static final int TAG_OPERATOR_EQUAL = 1;

  private final ZabbixProperties zabbixProperties;
  private final ZabbixHostGroupLookup hostGroupLookup;

  public AreaScopeResolver(ZabbixProperties zabbixProperties, ZabbixHostGroupLookup hostGroupLookup) {
    this.zabbixProperties = zabbixProperties;
    this.hostGroupLookup = hostGroupLookup;
  }

  public ZabbixScope resolve(Area area, ZabbixApiClient client, ZabbixConnection connection) {
    return switch (area.getFilterType()) {
      case HOST_GROUP -> resolveByGroup(area, client, connection);
      case TAG -> resolveByTag(area, client, connection);
    };
  }

  private ZabbixScope resolveByGroup(Area area, ZabbixApiClient client, ZabbixConnection connection) {
    List<String> names = area.groupNamesAsList();
    if (names.isEmpty()) return new ZabbixScope.GroupScope(List.of());
    List<String> groupIds = hostGroupLookup.resolveGroupIds(client, connection, names);
    return new ZabbixScope.GroupScope(groupIds);
  }

  private ZabbixScope resolveByTag(Area area, ZabbixApiClient client, ZabbixConnection connection) {
    if (area.getTagKey() == null || area.getTagKey().isBlank()) {
      return new ZabbixScope.IdScope(List.of(), List.of());
    }
    List<Map<String, Object>> tagFilter = List.of(Map.of(
        "tag", area.getTagKey(), "value", area.getTagValue() == null ? "" : area.getTagValue(),
        "operator", TAG_OPERATOR_EQUAL));

    JsonNode hostsResult = client.call(connection, "host.get", Map.of(
        "output", List.of("hostid"),
        "selectParentTemplates", List.of("templateid"),
        "tags", tagFilter));
    List<String> hostIds = new ArrayList<>();
    Set<String> templateIdsFromHosts = new LinkedHashSet<>();
    if (hostsResult != null) {
      hostsResult.forEach(h -> {
        hostIds.add(h.get("hostid").asText());
        JsonNode parents = h.get("parentTemplates");
        if (parents != null) parents.forEach(t -> templateIdsFromHosts.add(t.get("templateid").asText()));
      });
    }

    List<String> templateIds;
    if (zabbixProperties.isTemplateTagFilterSupported()) {
      try {
        JsonNode tplResult = client.call(connection, "template.get", Map.of(
            "output", List.of("templateid"), "tags", tagFilter));
        Set<String> direct = new LinkedHashSet<>();
        if (tplResult != null) tplResult.forEach(t -> direct.add(t.get("templateid").asText()));
        // Une com os templates herdados pelos hosts com a tag, para não perder nenhum.
        direct.addAll(templateIdsFromHosts);
        templateIds = new ArrayList<>(direct);
      } catch (Exception e) {
        log.warn("template.get não aceitou 'tags' nesta instância Zabbix — usando os templates dos hosts com a tag como fallback ({})", e.getMessage());
        templateIds = new ArrayList<>(templateIdsFromHosts);
      }
    } else {
      templateIds = new ArrayList<>(templateIdsFromHosts);
    }

    return new ZabbixScope.IdScope(hostIds, templateIds);
  }
}
