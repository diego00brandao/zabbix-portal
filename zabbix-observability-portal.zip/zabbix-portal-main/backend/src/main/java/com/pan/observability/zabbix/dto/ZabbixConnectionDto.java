package com.pan.observability.zabbix.dto;

import com.pan.observability.zabbix.ZabbixAuthType;
import com.pan.observability.zabbix.ZabbixConnection;

/** Nunca inclui token/senha na resposta — mesmo na tela oculta, evita expor segredo no front. */
public record ZabbixConnectionDto(Long id, String name, String url, ZabbixAuthType authType, String username, boolean active) {
  public static ZabbixConnectionDto from(ZabbixConnection c) {
    return new ZabbixConnectionDto(c.getId(), c.getName(), c.getUrl(), c.getAuthType(), c.getUsername(), c.isActive());
  }
}
