package com.pan.observability.auth;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "access_logs")
public class AccessLog {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String username;

  @Enumerated(EnumType.STRING)
  @Column(name = "auth_source")
  private AuthSource authSource;

  @Column(nullable = false)
  private String action;

  private String ip;

  @Column(name = "created_at", nullable = false)
  private LocalDateTime createdAt = LocalDateTime.now();

  public AccessLog() {}

  public AccessLog(String username, AuthSource authSource, String action, String ip) {
    this.username = username;
    this.authSource = authSource;
    this.action = action;
    this.ip = ip;
  }

  public Long getId() { return id; }
  public String getUsername() { return username; }
  public AuthSource getAuthSource() { return authSource; }
  public String getAction() { return action; }
  public String getIp() { return ip; }
  public LocalDateTime getCreatedAt() { return createdAt; }
}
