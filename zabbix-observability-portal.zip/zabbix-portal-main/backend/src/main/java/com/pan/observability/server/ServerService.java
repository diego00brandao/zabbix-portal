package com.pan.observability.server;

import com.pan.observability.area.AreaZabbixContext.Context;
import com.pan.observability.common.ApiException;
import com.pan.observability.zabbix.ZabbixItemFormatting;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

/** Porte de services/zabbix.js#getAllHosts + #getHostHealth (telas Servidores: lista + detalhe). */
@Service
public class ServerService {

  public List<Map<String, Object>> listServers(Context ctx) {
    if (ctx.scope().isEmpty()) return List.of();

    Map<String, Object> params = new LinkedHashMap<>();
    params.put("output", List.of("hostid", "host", "name", "status", "available", "description"));
    params.put("selectGroups", List.of("groupid", "name"));
    params.put("selectInterfaces", List.of("ip", "dns", "type", "available"));
    params.put("selectParentTemplates", List.of("templateid", "name"));
    params.put("selectTriggers", List.of("triggerid", "priority", "value"));
    params.put("filter", Map.of("status", "0"));
    params.put("limit", 2000);
    ctx.scope().applyToHostParams(params);

    List<Map<String, Object>> hosts = ctx.client().callList(ctx.connection(), "host.get", params);
    for (Map<String, Object> host : hosts) {
      enrichHostSummary(host);
    }
    return hosts;
  }

  @SuppressWarnings("unchecked")
  private void enrichHostSummary(Map<String, Object> host) {
    List<Map<String, Object>> interfaces = (List<Map<String, Object>>) host.getOrDefault("interfaces", List.of());
    String available = !interfaces.isEmpty() && interfaces.get(0).get("available") != null
        ? String.valueOf(interfaces.get(0).get("available"))
        : String.valueOf(host.getOrDefault("available", "0"));
    host.put("available", available);

    List<Map<String, Object>> triggers = (List<Map<String, Object>>) host.getOrDefault("triggers", List.of());
    int activeAlerts = 0;
    int maxSeverity = 0;
    for (Map<String, Object> t : triggers) {
      if ("1".equals(String.valueOf(t.get("value")))) {
        activeAlerts++;
        int priority = parseIntSafe(t.get("priority"));
        if (priority > maxSeverity) maxSeverity = priority;
      }
    }
    host.put("activeAlerts", activeAlerts);
    host.put("maxSeverity", maxSeverity);
  }

  public Map<String, Object> serverDetail(Context ctx, String hostId) {
    Map<String, Object> hostParams = Map.of(
        "output", List.of("hostid", "host", "name", "status", "available", "description"),
        "selectGroups", List.of("name"),
        "selectInterfaces", List.of("ip", "dns", "type"),
        "selectParentTemplates", List.of("templateid", "name"),
        "hostids", List.of(hostId));
    List<Map<String, Object>> hostResult = ctx.client().callList(ctx.connection(), "host.get", hostParams);
    if (hostResult.isEmpty()) throw ApiException.notFound("Servidor não encontrado");
    Map<String, Object> host = hostResult.get(0);

    List<Map<String, Object>> items = hostItems(ctx, hostId);
    List<Map<String, Object>> triggers = hostTriggers(ctx, hostId);
    List<Map<String, Object>> alerts = hostAlerts(ctx, hostId);

    long itemsActive = items.stream().filter(i -> "0".equals(String.valueOf(i.get("status")))).count();
    long itemsDisabled = items.stream().filter(i -> "1".equals(String.valueOf(i.get("status")))).count();
    long itemsQuery = items.stream().filter(i -> Boolean.TRUE.equals(i.get("isQuery"))).count();
    long triggersActive = triggers.stream().filter(t -> "0".equals(String.valueOf(t.get("status")))).count();
    long triggersDisabled = triggers.stream().filter(t -> "1".equals(String.valueOf(t.get("status")))).count();

    Map<String, Object> summary = new LinkedHashMap<>();
    summary.put("totalItems", items.size());
    summary.put("itemsActive", itemsActive);
    summary.put("itemsDisabled", itemsDisabled);
    summary.put("itemsQuery", itemsQuery);
    summary.put("totalTriggers", triggers.size());
    summary.put("triggersActive", triggersActive);
    summary.put("triggersDisabled", triggersDisabled);
    summary.put("activeAlerts", alerts.size());

    Map<String, Object> result = new LinkedHashMap<>();
    result.put("host", host);
    result.put("summary", summary);
    result.put("items", items);
    result.put("triggers", triggers);
    result.put("alerts", alerts);
    result.put("queryItems", items.stream().filter(i -> Boolean.TRUE.equals(i.get("isQuery"))).toList());
    result.put("generatedAt", LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
    return result;
  }

  private List<Map<String, Object>> hostItems(Context ctx, String hostId) {
    Map<String, Object> params = Map.of(
        "output", List.of("itemid", "name", "key_", "type", "delay", "history", "trends",
            "units", "params", "lastvalue", "lastclock", "status", "description", "error"),
        "hostids", List.of(hostId),
        "webitems", true,
        "limit", 500);
    List<Map<String, Object>> items = new ArrayList<>(ctx.client().callList(ctx.connection(), "item.get", params));
    for (Map<String, Object> item : items) {
      String type = String.valueOf(item.get("type"));
      String key = String.valueOf(item.getOrDefault("key_", ""));
      item.put("isQuery", ZabbixItemFormatting.isQueryItem(type, key));
      item.put("typeLabel", ZabbixItemFormatting.typeLabel(type));
      item.put("delayFormatted", ZabbixItemFormatting.formatDelay(String.valueOf(item.get("delay"))));
    }
    return items;
  }

  private List<Map<String, Object>> hostTriggers(Context ctx, String hostId) {
    Map<String, Object> params = Map.of(
        "output", List.of("triggerid", "description", "priority", "status", "expression", "lastchange", "comments"),
        "hostids", List.of(hostId),
        "sortfield", "priority", "sortorder", "DESC",
        "expandExpression", true);
    return ctx.client().callList(ctx.connection(), "trigger.get", params);
  }

  private List<Map<String, Object>> hostAlerts(Context ctx, String hostId) {
    Map<String, Object> params = Map.of(
        "output", List.of("triggerid", "description", "priority", "status", "expression", "lastchange"),
        "hostids", List.of(hostId),
        "expandExpression", true,
        "only_true", 1,
        "filter", Map.of("value", "1"),
        "monitored", true,
        "active", true,
        "sortfield", "priority", "sortorder", "DESC");
    return ctx.client().callList(ctx.connection(), "trigger.get", params);
  }

  private int parseIntSafe(Object value) {
    try {
      return Integer.parseInt(String.valueOf(value));
    } catch (Exception e) {
      return 0;
    }
  }
}
