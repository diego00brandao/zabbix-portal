package com.pan.observability.area;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "areas")
public class Area {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false, unique = true)
  private String name;

  private String description;

  @Column(nullable = false)
  private String color = "#3B82F6";

  @Enumerated(EnumType.STRING)
  @Column(name = "filter_type", nullable = false)
  private FilterType filterType = FilterType.HOST_GROUP;

  /** HOST_GROUP: nomes de grupo separados por vírgula (ex: "Banco de Dados,Oracle"). */
  @Column(name = "group_names")
  private String groupNames;

  /** TAG: chave da tag (ex: "portal"). */
  @Column(name = "tag_key")
  private String tagKey;

  /** TAG: valor da tag (ex: "dba"). */
  @Column(name = "tag_value")
  private String tagValue;

  @Column(name = "zabbix_connection_id")
  private Long zabbixConnectionId;

  @Column(name = "created_at", nullable = false)
  private LocalDateTime createdAt = LocalDateTime.now();

  @Column(name = "updated_at", nullable = false)
  private LocalDateTime updatedAt = LocalDateTime.now();

  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }
  public String getName() { return name; }
  public void setName(String name) { this.name = name; }
  public String getDescription() { return description; }
  public void setDescription(String description) { this.description = description; }
  public String getColor() { return color; }
  public void setColor(String color) { this.color = color; }
  public FilterType getFilterType() { return filterType; }
  public void setFilterType(FilterType filterType) { this.filterType = filterType; }
  public String getGroupNames() { return groupNames; }
  public void setGroupNames(String groupNames) { this.groupNames = groupNames; }
  public String getTagKey() { return tagKey; }
  public void setTagKey(String tagKey) { this.tagKey = tagKey; }
  public String getTagValue() { return tagValue; }
  public void setTagValue(String tagValue) { this.tagValue = tagValue; }
  public Long getZabbixConnectionId() { return zabbixConnectionId; }
  public void setZabbixConnectionId(Long zabbixConnectionId) { this.zabbixConnectionId = zabbixConnectionId; }
  public LocalDateTime getCreatedAt() { return createdAt; }
  public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
  public LocalDateTime getUpdatedAt() { return updatedAt; }
  public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

  public java.util.List<String> groupNamesAsList() {
    if (groupNames == null || groupNames.isBlank()) return java.util.List.of();
    return java.util.Arrays.stream(groupNames.split(",")).map(String::trim).filter(s -> !s.isBlank()).toList();
  }
}
