package com.pan.observability.auth;

import com.pan.observability.auth.dto.BlackbirdLoginRequest;
import com.pan.observability.auth.dto.LoginRequest;
import com.pan.observability.auth.dto.LoginResponse;
import com.pan.observability.auth.dto.UserDto;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

  private final LocalAuthService localAuthService;
  private final BlackbirdAuthService blackbirdAuthService;
  private final JwtService jwtService;
  private final AccessLogRepository accessLogRepository;

  public AuthController(LocalAuthService localAuthService, BlackbirdAuthService blackbirdAuthService,
                         JwtService jwtService, AccessLogRepository accessLogRepository) {
    this.localAuthService = localAuthService;
    this.blackbirdAuthService = blackbirdAuthService;
    this.jwtService = jwtService;
    this.accessLogRepository = accessLogRepository;
  }

  /** O front usa isso para decidir se mostra o botão "Entrar com Blackbird". */
  @GetMapping("/config")
  public Object config() {
    return java.util.Map.of("blackbirdEnabled", blackbirdAuthService.isEnabled());
  }

  @PostMapping("/login")
  public LoginResponse loginLocal(@Valid @RequestBody LoginRequest request, HttpServletRequest http) {
    AuthenticatedUser user = localAuthService.authenticate(request.username(), request.password());
    accessLogRepository.save(new AccessLog(user.username(), AuthSource.LOCAL, "login_success", clientIp(http)));
    return new LoginResponse(jwtService.issue(user), UserDto.from(user));
  }

  /** Método principal de login: o front chama isso com o token que o Blackbird emitiu. */
  @PostMapping("/login/blackbird")
  public LoginResponse loginBlackbird(@Valid @RequestBody BlackbirdLoginRequest request, HttpServletRequest http) {
    AuthenticatedUser user = blackbirdAuthService.authenticate(request.token());
    accessLogRepository.save(new AccessLog(user.username(), AuthSource.BLACKBIRD, "login_success", clientIp(http)));
    return new LoginResponse(jwtService.issue(user), UserDto.from(user));
  }

  @GetMapping("/me")
  public UserDto me(@AuthenticationPrincipal AuthenticatedUser user) {
    return UserDto.from(user);
  }

  @PostMapping("/logout")
  public Object logout(@AuthenticationPrincipal AuthenticatedUser user, HttpServletRequest http) {
    accessLogRepository.save(new AccessLog(user.username(), user.authSource(), "logout", clientIp(http)));
    return java.util.Map.of("message", "Logout realizado");
  }

  private String clientIp(HttpServletRequest req) {
    String fwd = req.getHeader("X-Forwarded-For");
    return fwd != null ? fwd.split(",")[0].trim() : req.getRemoteAddr();
  }
}
