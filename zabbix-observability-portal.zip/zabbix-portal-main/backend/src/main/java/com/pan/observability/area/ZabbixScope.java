package com.pan.observability.area;

import java.util.List;
import java.util.Map;

/**
 * Resultado de resolver a condição de uma área (grupo OU tag) para parâmetros
 * de chamada da API do Zabbix. Ver AreaScopeResolver para como cada
 * FilterType vira um destes.
 *
 * <p>{@code GroupScope} é usado quando a área é HOST_GROUP: o mesmo group id
 * filtra host.get, template.get, item.get, trigger.get e maintenance.get (no
 * Zabbix 6.0, host groups cobrem hosts e templates ao mesmo tempo — é o
 * parâmetro {@code groupids}).
 *
 * <p>{@code IdScope} é usado quando a área é TAG: como item.get/trigger.get
 * não filtram por tag do host/template (só pela tag do próprio item), a
 * AreaScopeResolver resolve antes os hostIds e templateIds que têm a tag, e
 * cada chamada usa o campo certo ({@code hostids} ou {@code templateids} —
 * nunca os dois juntos na mesma chamada, senão o Zabbix intersecta e não
 * retorna nada).
 */
public sealed interface ZabbixScope {

  record GroupScope(List<String> groupIds) implements ZabbixScope {}

  record IdScope(List<String> hostIds, List<String> templateIds) implements ZabbixScope {}

  /** true quando a área não tem nenhum host/template associado (evita chamada desnecessária ao Zabbix). */
  default boolean isEmpty() {
    return switch (this) {
      case GroupScope g -> g.groupIds().isEmpty();
      case IdScope i -> i.hostIds().isEmpty() && i.templateIds().isEmpty();
    };
  }

  /** Usado por host.get e maintenance.get (janelas de manutenção só se aplicam a hosts/grupos). */
  default void applyToHostParams(Map<String, Object> params) {
    switch (this) {
      case GroupScope g -> params.put("groupids", g.groupIds());
      case IdScope i -> params.put("hostids", i.hostIds());
    }
  }

  /** Usado por template.get e pelas chamadas de item.get/trigger.get da tela Itens & Triggers (escopo por template). */
  default void applyToTemplateParams(Map<String, Object> params) {
    switch (this) {
      case GroupScope g -> params.put("groupids", g.groupIds());
      case IdScope i -> params.put("templateids", i.templateIds());
    }
  }
}
