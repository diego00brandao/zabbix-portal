package com.pan.observability.zabbix;

import com.pan.observability.common.ApiException;
import org.springframework.stereotype.Component;

/** Resolve qual ZabbixConnection usar: a definida na área, ou a conexão marcada como ativa. */
@Component
public class ZabbixConnectionResolver {

  private final ZabbixConnectionRepository repository;

  public ZabbixConnectionResolver(ZabbixConnectionRepository repository) {
    this.repository = repository;
  }

  public ZabbixConnection resolve(Long connectionId) {
    if (connectionId != null) {
      return repository.findById(connectionId)
          .orElseThrow(() -> ApiException.badRequest("Conexão Zabbix da área não encontrada (id=" + connectionId + ")"));
    }
    return repository.findByActiveTrue()
        .orElseThrow(() -> ApiException.badRequest(
            "Nenhuma conexão Zabbix ativa configurada. Configure uma na tela de gestão de áreas."));
  }
}
