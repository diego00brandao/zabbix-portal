package com.pan.observability.auth;

import com.pan.observability.common.ApiException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import java.nio.charset.StandardCharsets;
import javax.crypto.SecretKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Login via Blackbird — é o método PRINCIPAL de autenticação (ver
 * LocalAuthService para o fallback usado quando o Blackbird cai).
 *
 * A integração real com o Blackbird ainda não tem contrato fechado, então
 * esta classe fica isolada atrás de {@link #authenticate(String)}: hoje ela
 * valida um JWT assinado com segredo compartilhado (HMAC) que o Blackbird
 * envia para o portal depois de autenticar o usuário. Quando o time do
 * Blackbird definir o formato final (ex: redirect OAuth2/OIDC com JWKS,
 * outro claim set, etc.), só este arquivo precisa mudar — o resto do
 * sistema já trabalha em cima de {@link AuthenticatedUser}.
 */
@Service
public class BlackbirdAuthService {

  private static final Logger log = LoggerFactory.getLogger(BlackbirdAuthService.class);

  private final PortalAuthProperties properties;
  private final ManagerService managerService;

  public BlackbirdAuthService(PortalAuthProperties properties, ManagerService managerService) {
    this.properties = properties;
    this.managerService = managerService;
  }

  public boolean isEnabled() {
    return properties.getAuth().getBlackbird().isEnabled();
  }

  public AuthenticatedUser authenticate(String blackbirdToken) {
    PortalAuthProperties.Blackbird cfg = properties.getAuth().getBlackbird();
    if (!cfg.isEnabled()) {
      throw ApiException.forbidden("Login via Blackbird não está habilitado neste ambiente");
    }
    if (blackbirdToken == null || blackbirdToken.isBlank()) {
      throw ApiException.badRequest("Token do Blackbird não informado");
    }
    if (cfg.getJwksUri() != null && !cfg.getJwksUri().isBlank()) {
      // TODO: plugar validação RS256 via JWKS quando o Blackbird disponibilizar o endpoint.
      throw ApiException.badRequest(
          "Validação via JWKS ainda não implementada — configure BLACKBIRD_SHARED_SECRET "
              + "(HMAC) ou implemente BlackbirdAuthService#authenticate para o formato real do token.");
    }
    if (cfg.getSharedSecret() == null || cfg.getSharedSecret().isBlank()) {
      throw ApiException.badRequest("BLACKBIRD_SHARED_SECRET não configurado");
    }

    try {
      SecretKey key = Keys.hmacShaKeyFor(cfg.getSharedSecret().getBytes(StandardCharsets.UTF_8));
      Claims claims = Jwts.parser().verifyWith(key).build()
          .parseSignedClaims(blackbirdToken).getPayload();

      if (cfg.getExpectedIssuer() != null && !cfg.getExpectedIssuer().isBlank()
          && !cfg.getExpectedIssuer().equals(claims.getIssuer())) {
        throw ApiException.unauthorized("Token do Blackbird com issuer inesperado");
      }

      String username = claims.get(cfg.getUsernameClaim(), String.class);
      if (username == null || username.isBlank()) {
        username = claims.getSubject();
      }
      if (username == null || username.isBlank()) {
        throw ApiException.unauthorized("Token do Blackbird sem identificação de usuário");
      }
      String fullName = claims.get(cfg.getFullnameClaim(), String.class);
      String email = claims.get(cfg.getEmailClaim(), String.class);

      return new AuthenticatedUser(
          username.toLowerCase(),
          fullName != null ? fullName : username,
          email,
          AuthSource.BLACKBIRD,
          managerService.isManager(username));
    } catch (JwtException | IllegalArgumentException e) {
      log.warn("Falha ao validar token do Blackbird: {}", e.getMessage());
      throw ApiException.unauthorized("Token do Blackbird inválido ou expirado");
    }
  }
}
