package com.pan.observability.zabbix;

import java.util.Map;

/** Pequenos helpers de apresentação — porte de trechos de services/zabbix.js (getItemTypeLabel/formatDelay). */
public final class ZabbixItemFormatting {

  private ZabbixItemFormatting() {}

  private static final Map<String, String> TYPE_LABELS = Map.ofEntries(
      Map.entry("0", "Zabbix Agent"), Map.entry("2", "Zabbix Trapper"), Map.entry("3", "Simple Check"),
      Map.entry("5", "Zabbix Internal"), Map.entry("7", "Zabbix Agent (Active)"), Map.entry("10", "External Check"),
      Map.entry("11", "Database Monitor"), Map.entry("12", "IPMI Agent"), Map.entry("13", "SSH Agent"),
      Map.entry("14", "Telnet Agent"), Map.entry("15", "Calculated"), Map.entry("16", "JMX Agent"),
      Map.entry("17", "SNMP Trap"), Map.entry("18", "Dependent Item"), Map.entry("19", "HTTP Agent"),
      Map.entry("20", "SNMP Agent"));

  public static String typeLabel(String type) {
    return TYPE_LABELS.getOrDefault(type, type);
  }

  public static boolean isQueryItem(String type, String key) {
    return "11".equals(type) || (key != null && (key.startsWith("db.odbc") || key.startsWith("db.query")));
  }

  public static String formatDelay(String delay) {
    if (delay == null || delay.isBlank()) return "N/A";
    java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d+)([smhd]?)$").matcher(delay);
    if (!m.matches()) return delay;
    long n = Long.parseLong(m.group(1));
    String unit = m.group(2);
    if (unit.isEmpty() || unit.equals("s")) {
      if (n >= 86400) return (n / 86400) + " dia(s)";
      if (n >= 3600) return (n / 3600) + " hora(s)";
      if (n >= 60) return (n / 60) + " min";
      return n + " seg";
    }
    return n + " " + switch (unit) {
      case "m" -> "min";
      case "h" -> "hora(s)";
      case "d" -> "dia(s)";
      default -> unit;
    };
  }
}
