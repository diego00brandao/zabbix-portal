package com.pan.observability.zabbix;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ZabbixConnectionRepository extends JpaRepository<ZabbixConnection, Long> {
  Optional<ZabbixConnection> findByActiveTrue();
}
