package com.pan.observability.zabbix;

public enum ZabbixAuthType {
  TOKEN,
  USERPASS
}
