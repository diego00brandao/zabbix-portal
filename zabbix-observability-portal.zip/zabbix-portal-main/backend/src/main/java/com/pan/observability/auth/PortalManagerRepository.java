package com.pan.observability.auth;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PortalManagerRepository extends JpaRepository<PortalManager, Long> {
  Optional<PortalManager> findByUsernameIgnoreCase(String username);
  boolean existsByUsernameIgnoreCase(String username);
}
