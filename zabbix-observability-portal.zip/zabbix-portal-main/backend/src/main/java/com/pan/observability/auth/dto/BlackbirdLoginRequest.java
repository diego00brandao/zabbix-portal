package com.pan.observability.auth.dto;

import jakarta.validation.constraints.NotBlank;

/** Token que o Blackbird emite após autenticar o usuário (ver BlackbirdAuthService). */
public record BlackbirdLoginRequest(@NotBlank String token) {}
