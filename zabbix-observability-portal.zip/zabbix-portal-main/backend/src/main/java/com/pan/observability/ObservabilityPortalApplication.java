package com.pan.observability;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@ConfigurationPropertiesScan
@EnableCaching
public class ObservabilityPortalApplication {

  public static void main(String[] args) {
    SpringApplication.run(ObservabilityPortalApplication.class, args);
  }
}
