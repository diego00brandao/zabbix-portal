package com.pan.observability.auth;

import com.pan.observability.auth.dto.PortalManagerDto;
import com.pan.observability.common.ApiException;
import jakarta.validation.constraints.NotBlank;
import java.util.List;
import java.util.Map;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Também faz parte da tela oculta: quem já gerencia o portal pode dar (ou
 * tirar) esse acesso de outra pessoa, sem precisar mexer na variável de
 * ambiente de bootstrap (PORTAL_MANAGER_USERNAMES).
 */
@RestController
@RequestMapping("/api/manage/managers")
public class ManagerAdminController {

  private final PortalManagerRepository repository;
  private final ManagerGuard managerGuard;

  public ManagerAdminController(PortalManagerRepository repository, ManagerGuard managerGuard) {
    this.repository = repository;
    this.managerGuard = managerGuard;
  }

  public record AddManagerRequest(@NotBlank String username) {}

  @GetMapping
  public List<PortalManagerDto> list(@AuthenticationPrincipal AuthenticatedUser user) {
    managerGuard.require(user);
    return repository.findAll().stream().map(PortalManagerDto::from).toList();
  }

  @PostMapping
  public PortalManagerDto add(@AuthenticationPrincipal AuthenticatedUser user, @RequestBody AddManagerRequest req) {
    managerGuard.require(user);
    String username = req.username().trim().toLowerCase();
    if (repository.existsByUsernameIgnoreCase(username)) {
      throw ApiException.badRequest("Esse usuário já gerencia o portal");
    }
    PortalManager m = new PortalManager();
    m.setUsername(username);
    m.setAddedBy(user.username());
    return PortalManagerDto.from(repository.save(m));
  }

  @DeleteMapping("/{id}")
  public Map<String, Boolean> remove(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long id) {
    managerGuard.require(user);
    PortalManager m = repository.findById(id).orElseThrow(() -> ApiException.notFound("Gestor não encontrado"));
    if (m.getUsername().equalsIgnoreCase(user.username())) {
      throw ApiException.badRequest("Não é possível remover seu próprio acesso de gestor");
    }
    repository.deleteById(id);
    return Map.of("success", true);
  }
}
