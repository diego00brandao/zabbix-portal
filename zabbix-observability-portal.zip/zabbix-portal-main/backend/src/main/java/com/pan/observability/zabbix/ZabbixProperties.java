package com.pan.observability.zabbix;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "zabbix")
public class ZabbixProperties {

  private int requestTimeoutMs = 15000;
  /**
   * Nem toda instância Zabbix aceita o parâmetro "tags" em template.get (isso
   * depende da versão). Quando falso, o AreaScopeResolver deriva os
   * templates de uma área com condição por TAG a partir dos hosts que têm a
   * tag (via parentTemplates), em vez de filtrar templates diretamente.
   */
  private boolean templateTagFilterSupported = true;

  public int getRequestTimeoutMs() { return requestTimeoutMs; }
  public void setRequestTimeoutMs(int requestTimeoutMs) { this.requestTimeoutMs = requestTimeoutMs; }
  public boolean isTemplateTagFilterSupported() { return templateTagFilterSupported; }
  public void setTemplateTagFilterSupported(boolean templateTagFilterSupported) {
    this.templateTagFilterSupported = templateTagFilterSupported;
  }
}
