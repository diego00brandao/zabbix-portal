package com.pan.observability.area.dto;

import com.pan.observability.area.Area;

/**
 * O que a tela "Selecionar Área" (usuário final) enxerga — nunca inclui
 * filterType/valores, conforme pedido (a condição fica invisível pro
 * usuário final, só quem gerencia o portal vê/edita isso).
 */
public record AreaPublicDto(Long id, String name, String description, String color) {
  public static AreaPublicDto from(Area a) {
    return new AreaPublicDto(a.getId(), a.getName(), a.getDescription(), a.getColor());
  }
}
