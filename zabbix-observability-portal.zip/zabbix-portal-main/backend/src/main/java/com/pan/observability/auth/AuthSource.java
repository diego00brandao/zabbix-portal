package com.pan.observability.auth;

/** De onde veio a identidade do usuário autenticado nesta sessão. */
public enum AuthSource {
  BLACKBIRD,
  LOCAL
}
