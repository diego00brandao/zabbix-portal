package com.pan.observability.zabbix;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

/** Uma instância Zabbix que o portal sabe consultar (suporte a multi-Zabbix, como no portal atual). */
@Entity
@Table(name = "zabbix_connections")
public class ZabbixConnection {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false)
  private String name;

  @Column(nullable = false)
  private String url;

  @Enumerated(EnumType.STRING)
  @Column(name = "auth_type", nullable = false)
  private ZabbixAuthType authType = ZabbixAuthType.TOKEN;

  private String token;
  private String username;
  private String password;

  @Column(nullable = false)
  private boolean active = false;

  @Column(name = "created_at", nullable = false)
  private LocalDateTime createdAt = LocalDateTime.now();

  @Column(name = "updated_at", nullable = false)
  private LocalDateTime updatedAt = LocalDateTime.now();

  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }
  public String getName() { return name; }
  public void setName(String name) { this.name = name; }
  public String getUrl() { return url; }
  public void setUrl(String url) { this.url = url; }
  public ZabbixAuthType getAuthType() { return authType; }
  public void setAuthType(ZabbixAuthType authType) { this.authType = authType; }
  public String getToken() { return token; }
  public void setToken(String token) { this.token = token; }
  public String getUsername() { return username; }
  public void setUsername(String username) { this.username = username; }
  public String getPassword() { return password; }
  public void setPassword(String password) { this.password = password; }
  public boolean isActive() { return active; }
  public void setActive(boolean active) { this.active = active; }
  public LocalDateTime getCreatedAt() { return createdAt; }
  public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
  public LocalDateTime getUpdatedAt() { return updatedAt; }
  public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
