package com.pan.observability.area.dto;

import com.pan.observability.area.Area;
import com.pan.observability.area.FilterType;

/** Visão completa da área — só para a tela oculta de gestão. */
public record AreaAdminDto(
    Long id,
    String name,
    String description,
    String color,
    FilterType filterType,
    String groupNames,
    String tagKey,
    String tagValue,
    Long zabbixConnectionId
) {
  public static AreaAdminDto from(Area a) {
    return new AreaAdminDto(a.getId(), a.getName(), a.getDescription(), a.getColor(), a.getFilterType(),
        a.getGroupNames(), a.getTagKey(), a.getTagValue(), a.getZabbixConnectionId());
  }
}
