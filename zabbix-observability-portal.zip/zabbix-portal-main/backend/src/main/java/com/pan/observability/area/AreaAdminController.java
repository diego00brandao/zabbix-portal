package com.pan.observability.area;

import com.pan.observability.area.dto.AreaAdminDto;
import com.pan.observability.area.dto.AreaUpsertRequest;
import com.pan.observability.auth.AuthenticatedUser;
import com.pan.observability.auth.ManagerGuard;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Tela oculta de gestão de áreas — NÃO fica em nenhum menu do front, e só
 * responde para quem está em portal_managers (ver ManagerGuard). É aqui que
 * se cadastra área nova e se escolhe grupo vs tag (nunca fixo no código).
 */
@RestController
@RequestMapping("/api/manage/areas")
public class AreaAdminController {

  private final AreaService areaService;
  private final ManagerGuard managerGuard;

  public AreaAdminController(AreaService areaService, ManagerGuard managerGuard) {
    this.areaService = areaService;
    this.managerGuard = managerGuard;
  }

  @GetMapping
  public List<AreaAdminDto> list(@AuthenticationPrincipal AuthenticatedUser user) {
    managerGuard.require(user);
    return areaService.listAll().stream().map(AreaAdminDto::from).toList();
  }

  @PostMapping
  public AreaAdminDto create(@AuthenticationPrincipal AuthenticatedUser user, @Valid @RequestBody AreaUpsertRequest req) {
    managerGuard.require(user);
    return AreaAdminDto.from(areaService.create(req));
  }

  @PutMapping("/{id}")
  public AreaAdminDto update(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long id,
                              @Valid @RequestBody AreaUpsertRequest req) {
    managerGuard.require(user);
    return AreaAdminDto.from(areaService.update(id, req));
  }

  @DeleteMapping("/{id}")
  public Map<String, Boolean> delete(@AuthenticationPrincipal AuthenticatedUser user, @PathVariable Long id) {
    managerGuard.require(user);
    areaService.delete(id);
    return Map.of("success", true);
  }
}
