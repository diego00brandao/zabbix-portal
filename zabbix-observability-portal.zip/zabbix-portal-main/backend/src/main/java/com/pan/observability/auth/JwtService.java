package com.pan.observability.auth;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import org.springframework.stereotype.Service;

/**
 * Emite/valida o JWT interno do portal — usado nas chamadas seguintes,
 * independente de o login original ter vindo do Blackbird ou do fallback
 * local (ver AuthenticatedUser).
 */
@Service
public class JwtService {

  private final Key key;
  private final Duration expiration;

  public JwtService(PortalAuthProperties properties) {
    String secret = properties.getJwt().getSecret();
    if (secret == null || secret.getBytes(StandardCharsets.UTF_8).length < 32) {
      // HMAC-SHA256 exige pelo menos 256 bits; preenche se o segredo configurado for curto
      // (só deve acontecer em dev — em produção configure PORTAL_JWT_SECRET com >= 32 bytes).
      secret = (secret == null ? "" : secret) + "0".repeat(32);
    }
    this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    this.expiration = Duration.ofMinutes(properties.getJwt().getExpirationMinutes());
  }

  public String issue(AuthenticatedUser user) {
    Instant now = Instant.now();
    return Jwts.builder()
        .subject(user.username())
        .claim("fullName", user.fullName())
        .claim("email", user.email())
        .claim("authSource", user.authSource().name())
        .claim("portalManager", user.portalManager())
        .issuedAt(Date.from(now))
        .expiration(Date.from(now.plus(expiration)))
        .signWith(key)
        .compact();
  }

  public AuthenticatedUser parse(String token) {
    try {
      Claims claims = Jwts.parser().verifyWith((javax.crypto.SecretKey) key).build()
          .parseSignedClaims(token).getPayload();
      return new AuthenticatedUser(
          claims.getSubject(),
          claims.get("fullName", String.class),
          claims.get("email", String.class),
          AuthSource.valueOf(claims.get("authSource", String.class)),
          Boolean.TRUE.equals(claims.get("portalManager", Boolean.class))
      );
    } catch (JwtException | IllegalArgumentException e) {
      throw com.pan.observability.common.ApiException.unauthorized("Token inválido ou expirado");
    }
  }
}
