package com.pan.observability.maintenance;

import com.pan.observability.area.AreaZabbixContext.Context;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

/** Porte de routes/zabbix.js `/maintenances` — somente leitura. */
@Service
public class MaintenanceService {

  public List<Map<String, Object>> list(Context ctx) {
    if (ctx.scope().isEmpty()) return List.of();

    Map<String, Object> params = new LinkedHashMap<>();
    params.put("output", List.of("maintenanceid", "name", "description", "active_since", "active_till", "maintenance_type"));
    params.put("selectHosts", List.of("hostid", "host", "name"));
    params.put("selectGroups", List.of("groupid", "name"));
    params.put("selectTimeperiods", "extend");
    params.put("sortfield", "name");
    ctx.scope().applyToHostParams(params);

    return ctx.client().callList(ctx.connection(), "maintenance.get", params);
  }
}
