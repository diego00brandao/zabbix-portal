package com.pan.observability.area;

import com.pan.observability.area.dto.AreaUpsertRequest;
import com.pan.observability.common.ApiException;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AreaService {

  private final AreaRepository repository;

  public AreaService(AreaRepository repository) {
    this.repository = repository;
  }

  public List<Area> listAll() {
    return repository.findAll().stream().sorted(Comparator.comparing(Area::getName)).toList();
  }

  public Area getOrThrow(Long id) {
    return repository.findById(id).orElseThrow(() -> ApiException.notFound("Área não encontrada"));
  }

  /**
   * Usado pelos endpoints de dados (Servidores/Manutenções/Itens & Triggers)
   * para resolver a área selecionada pelo usuário via header X-Area-Id.
   */
  public Area requireSelectedArea(Long areaId) {
    if (areaId == null) {
      throw ApiException.badRequest("Nenhuma área selecionada — selecione uma área antes de continuar");
    }
    return getOrThrow(areaId);
  }

  @Transactional
  public Area create(AreaUpsertRequest req) {
    repository.findByNameIgnoreCase(req.name()).ifPresent(a -> {
      throw ApiException.badRequest("Já existe uma área com esse nome");
    });
    Area area = new Area();
    applyRequest(area, req);
    return repository.save(area);
  }

  @Transactional
  public Area update(Long id, AreaUpsertRequest req) {
    Area area = getOrThrow(id);
    repository.findByNameIgnoreCase(req.name()).ifPresent(other -> {
      if (!other.getId().equals(id)) throw ApiException.badRequest("Já existe uma área com esse nome");
    });
    applyRequest(area, req);
    area.setUpdatedAt(LocalDateTime.now());
    return repository.save(area);
  }

  @Transactional
  public void delete(Long id) {
    if (!repository.existsById(id)) throw ApiException.notFound("Área não encontrada");
    repository.deleteById(id);
  }

  private void applyRequest(Area area, AreaUpsertRequest req) {
    area.setName(req.name().trim());
    area.setDescription(req.description());
    area.setColor(req.color() == null || req.color().isBlank() ? "#3B82F6" : req.color());
    area.setFilterType(req.filterType());
    area.setGroupNames(req.groupNames());
    area.setTagKey(req.tagKey());
    area.setTagValue(req.tagValue());
    area.setZabbixConnectionId(req.zabbixConnectionId());

    if (req.filterType() == FilterType.HOST_GROUP
        && (req.groupNames() == null || req.groupNames().isBlank())) {
      throw ApiException.badRequest("Informe ao menos um grupo para a condição por grupo");
    }
    if (req.filterType() == FilterType.TAG
        && (req.tagKey() == null || req.tagKey().isBlank())) {
      throw ApiException.badRequest("Informe a chave da tag para a condição por tag");
    }
  }
}
