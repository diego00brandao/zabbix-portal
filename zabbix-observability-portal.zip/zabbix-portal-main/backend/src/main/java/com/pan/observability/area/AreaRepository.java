package com.pan.observability.area;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AreaRepository extends JpaRepository<Area, Long> {
  Optional<Area> findByNameIgnoreCase(String name);
}
