package com.pan.observability.area;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.matchingJsonPath;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.pan.observability.zabbix.ZabbixApiClient;
import com.pan.observability.zabbix.ZabbixAuthType;
import com.pan.observability.zabbix.ZabbixConnection;
import com.pan.observability.zabbix.ZabbixProperties;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Cobre o ponto mais sensível do pedido do usuário: a mesma área pode ser
 * filtrada por GRUPO ou por TAG (escolha de quem gerencia o portal, nunca
 * fixa no código) — aqui validamos que os dois caminhos produzem os
 * parâmetros certos para a API do Zabbix, contra um Zabbix "fake" (WireMock).
 */
class AreaScopeResolverTest {

  private WireMockServer wireMock;
  private ZabbixConnection connection;
  private ZabbixApiClient client;

  @BeforeEach
  void setUp() {
    wireMock = new WireMockServer(WireMockConfiguration.options().dynamicPort());
    wireMock.start();

    connection = new ZabbixConnection();
    connection.setId(1L);
    connection.setName("fake-zabbix");
    connection.setUrl("http://localhost:" + wireMock.port() + "/api_jsonrpc.php");
    connection.setAuthType(ZabbixAuthType.TOKEN);
    connection.setToken("test-token");

    ZabbixProperties properties = new ZabbixProperties();
    properties.setTemplateTagFilterSupported(true);
    client = new ZabbixApiClient(properties);
  }

  @AfterEach
  void tearDown() {
    wireMock.stop();
  }

  @Test
  void resolvesHostGroupCondition() {
    stubFor(post(urlEqualTo("/api_jsonrpc.php"))
        .withRequestBody(matchingJsonPath("$.method", equalTo("hostgroup.get")))
        .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json").withBody(
            "{\"jsonrpc\":\"2.0\",\"result\":[{\"groupid\":\"10\",\"name\":\"Banco de Dados\"}],\"id\":1}")));

    Area area = new Area();
    area.setFilterType(FilterType.HOST_GROUP);
    area.setGroupNames("Banco de Dados");

    ZabbixProperties properties = new ZabbixProperties();
    AreaScopeResolver resolver = new AreaScopeResolver(properties, new ZabbixHostGroupLookup());

    ZabbixScope scope = resolver.resolve(area, client, connection);

    assertThat(scope).isInstanceOf(ZabbixScope.GroupScope.class);
    assertThat(((ZabbixScope.GroupScope) scope).groupIds()).containsExactly("10");
  }

  @Test
  void resolvesTagConditionUsingHostsAndTemplates() {
    stubFor(post(urlEqualTo("/api_jsonrpc.php"))
        .withRequestBody(matchingJsonPath("$.method", equalTo("host.get")))
        .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json").withBody(
            "{\"jsonrpc\":\"2.0\",\"result\":[{\"hostid\":\"100\",\"parentTemplates\":[{\"templateid\":\"200\"}]}],\"id\":1}")));

    stubFor(post(urlEqualTo("/api_jsonrpc.php"))
        .withRequestBody(matchingJsonPath("$.method", equalTo("template.get")))
        .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json").withBody(
            "{\"jsonrpc\":\"2.0\",\"result\":[{\"templateid\":\"200\"}],\"id\":1}")));

    Area area = new Area();
    area.setFilterType(FilterType.TAG);
    area.setTagKey("portal");
    area.setTagValue("network");

    ZabbixProperties properties = new ZabbixProperties();
    properties.setTemplateTagFilterSupported(true);
    AreaScopeResolver resolver = new AreaScopeResolver(properties, new ZabbixHostGroupLookup());

    ZabbixScope scope = resolver.resolve(area, client, connection);

    assertThat(scope).isInstanceOf(ZabbixScope.IdScope.class);
    ZabbixScope.IdScope idScope = (ZabbixScope.IdScope) scope;
    assertThat(idScope.hostIds()).containsExactly("100");
    assertThat(idScope.templateIds()).containsExactly("200");
  }

  @Test
  void resolvesTagConditionFallingBackToHostParentTemplatesWhenTemplateTagsUnsupported() {
    stubFor(post(urlEqualTo("/api_jsonrpc.php"))
        .withRequestBody(matchingJsonPath("$.method", equalTo("host.get")))
        .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json").withBody(
            "{\"jsonrpc\":\"2.0\",\"result\":[{\"hostid\":\"101\",\"parentTemplates\":[{\"templateid\":\"201\"}]}],\"id\":1}")));

    Area area = new Area();
    area.setFilterType(FilterType.TAG);
    area.setTagKey("portal");
    area.setTagValue("dba");

    ZabbixProperties properties = new ZabbixProperties();
    properties.setTemplateTagFilterSupported(false); // instância Zabbix sem suporte a tags em template.get
    AreaScopeResolver resolver = new AreaScopeResolver(properties, new ZabbixHostGroupLookup());

    ZabbixScope scope = resolver.resolve(area, client, connection);

    assertThat(scope).isInstanceOf(ZabbixScope.IdScope.class);
    ZabbixScope.IdScope idScope = (ZabbixScope.IdScope) scope;
    assertThat(idScope.hostIds()).containsExactly("101");
    // template.get nunca deveria ter sido chamado; templateIds vem só do parentTemplates dos hosts.
    assertThat(idScope.templateIds()).containsExactly("201");
    wireMock.verify(0, com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor(urlEqualTo("/api_jsonrpc.php"))
        .withRequestBody(matchingJsonPath("$.method", equalTo("template.get"))));
  }

  @Test
  void emptyGroupConditionResultsInEmptyScope() {
    Area area = new Area();
    area.setFilterType(FilterType.HOST_GROUP);
    area.setGroupNames(null);

    ZabbixProperties properties = new ZabbixProperties();
    AreaScopeResolver resolver = new AreaScopeResolver(properties, new ZabbixHostGroupLookup());

    ZabbixScope scope = resolver.resolve(area, client, connection);

    assertThat(scope.isEmpty()).isTrue();
  }
}
