export const environment = {
  production: true,
  // URL para onde o botão "Entrar com Blackbird" redireciona. O Blackbird,
  // depois de autenticar o usuário, deve redirecionar de volta para
  // `<origem do portal>/portal/login?bb_token=<token>`. Preencher quando o
  // time do Blackbird definir o endpoint real (ver README da integração).
  blackbirdLoginUrl: '',
};
