export const environment = {
  production: false,
  blackbirdLoginUrl: '',
};
