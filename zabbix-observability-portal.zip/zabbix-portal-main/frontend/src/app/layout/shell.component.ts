import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet, Router } from '@angular/router';
import { AuthService } from '../core/auth/auth.service';
import { AreaService } from '../core/area/area.service';

/**
 * Shell autenticado — só as 3 telas pedidas (Servidores, Manutenções,
 * Itens & Triggers). Sem nenhum link para a gestão de áreas: essa tela é
 * oculta de propósito (acessível só por URL direta, para quem gerencia o
 * portal — ver app.routes.ts e managerGuard).
 */
@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './shell.component.html',
  styleUrl: './shell.component.css',
})
export class ShellComponent {
  readonly navItems = [
    { to: '/servers', icon: '⬡', label: 'Servidores' },
    { to: '/maintenance', icon: '⊙', label: 'Manutenções' },
    { to: '/items-triggers', icon: '⊞', label: 'Itens & Triggers' },
  ];

  constructor(public auth: AuthService, public areaService: AreaService, private router: Router) {}

  switchArea(): void {
    this.areaService.clear();
    this.router.navigate(['/select-area']);
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
