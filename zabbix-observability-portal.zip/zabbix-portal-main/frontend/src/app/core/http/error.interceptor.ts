import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../auth/auth.service';

/**
 * 401 = sessão expirada/inválida -> volta pro login.
 * 403 NÃO desloga: pode ser só "esse usuário não é gestor do portal" numa
 * rota oculta — quem chamou decide o que fazer (ex: redirecionar pra home).
 */
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return next(req).pipe(
    catchError((err) => {
      const isLoginRoute = req.url.includes('/api/auth/login');
      if (err.status === 401 && !isLoginRoute) {
        auth.logout();
        router.navigate(['/login']);
      }
      return throwError(() => err);
    })
  );
};
