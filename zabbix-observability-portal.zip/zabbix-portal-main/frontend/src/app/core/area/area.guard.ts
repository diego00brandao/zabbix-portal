import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AreaService } from './area.service';

/** As telas de dados (Servidores/Manutenções/Itens & Triggers) exigem uma área escolhida. */
export const areaGuard: CanActivateFn = () => {
  const area = inject(AreaService).selected();
  if (area) return true;
  inject(Router).navigate(['/select-area']);
  return false;
};
