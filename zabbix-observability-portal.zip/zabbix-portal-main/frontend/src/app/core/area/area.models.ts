export interface AreaPublic {
  id: number;
  name: string;
  description: string | null;
  color: string;
}

export type FilterType = 'HOST_GROUP' | 'TAG';

export interface AreaAdmin {
  id: number;
  name: string;
  description: string | null;
  color: string;
  filterType: FilterType;
  groupNames: string | null;
  tagKey: string | null;
  tagValue: string | null;
  zabbixConnectionId: number | null;
}

export interface AreaUpsertRequest {
  name: string;
  description: string | null;
  color: string;
  filterType: FilterType;
  groupNames: string | null;
  tagKey: string | null;
  tagValue: string | null;
  zabbixConnectionId: number | null;
}
