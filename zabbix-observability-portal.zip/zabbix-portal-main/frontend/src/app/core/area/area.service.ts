import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { AreaPublic } from './area.models';

const AREA_KEY = 'selected_area';

/**
 * Depois do login, o usuário escolhe a área (Banco de Dados, Network...) —
 * é essa escolha que decide quais servidores/manutenções/itens ele vê. A
 * área selecionada vai em cada chamada via header X-Area-Id.
 */
@Injectable({ providedIn: 'root' })
export class AreaService {
  private readonly _selected = signal<AreaPublic | null>(this.readStored());
  readonly selected = this._selected.asReadonly();

  constructor(private http: HttpClient) {}

  list(): Observable<AreaPublic[]> {
    return this.http.get<AreaPublic[]>('/api/areas');
  }

  select(area: AreaPublic): void {
    localStorage.setItem(AREA_KEY, JSON.stringify(area));
    this._selected.set(area);
  }

  clear(): void {
    localStorage.removeItem(AREA_KEY);
    this._selected.set(null);
  }

  private readStored(): AreaPublic | null {
    try {
      const raw = localStorage.getItem(AREA_KEY);
      return raw ? (JSON.parse(raw) as AreaPublic) : null;
    } catch {
      return null;
    }
  }
}
