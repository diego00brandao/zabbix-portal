import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AreaService } from './area.service';

/** Anexa X-Area-Id em toda chamada à nossa API, quando já houver área selecionada. */
export const areaInterceptor: HttpInterceptorFn = (req, next) => {
  const area = inject(AreaService).selected();
  if (!area || !req.url.startsWith('/api')) return next(req);
  return next(req.clone({ setHeaders: { 'X-Area-Id': String(area.id) } }));
};
