import { Injectable, computed, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { AuthConfig, LoginResponse, PortalUser } from './auth.models';

const TOKEN_KEY = 'portal_token';

/**
 * Login duplo: Blackbird é o método principal (loginBlackbird), login local
 * é o fallback usado quando o Blackbird está fora do ar (login). Os dois
 * endpoints devolvem o mesmo token interno do portal — a partir daí não
 * importa mais de onde o usuário veio.
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly _user = signal<PortalUser | null>(null);
  readonly user = this._user.asReadonly();
  readonly isManager = computed(() => this._user()?.portalManager ?? false);

  constructor(private http: HttpClient) {}

  get token(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  isAuthenticated(): boolean {
    return !!this.token;
  }

  config(): Observable<AuthConfig> {
    return this.http.get<AuthConfig>('/api/auth/config');
  }

  login(username: string, password: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>('/api/auth/login', { username, password }).pipe(
      tap((res) => this.applyLogin(res))
    );
  }

  loginBlackbird(token: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>('/api/auth/login/blackbird', { token }).pipe(
      tap((res) => this.applyLogin(res))
    );
  }

  /** Carrega o usuário a partir do token salvo (refresh de página). */
  loadMe(): Observable<PortalUser> {
    return this.http.get<PortalUser>('/api/auth/me').pipe(tap((user) => this._user.set(user)));
  }

  logout(): void {
    this.http.post('/api/auth/logout', {}).subscribe({ complete: () => {}, error: () => {} });
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem('selected_area');
    this._user.set(null);
  }

  private applyLogin(res: LoginResponse): void {
    localStorage.setItem(TOKEN_KEY, res.token);
    this._user.set(res.user);
  }
}
