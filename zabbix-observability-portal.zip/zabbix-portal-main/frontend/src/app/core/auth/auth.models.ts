export type AuthSource = 'BLACKBIRD' | 'LOCAL';

export interface PortalUser {
  username: string;
  fullName: string;
  email: string | null;
  authSource: AuthSource;
  portalManager: boolean;
}

export interface LoginResponse {
  token: string;
  user: PortalUser;
}

export interface AuthConfig {
  blackbirdEnabled: boolean;
}
