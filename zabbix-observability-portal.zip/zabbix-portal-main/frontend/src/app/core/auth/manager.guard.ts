import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';

/**
 * Protege a rota oculta de gestão de áreas — não fica em nenhum menu, e só
 * quem está em portal_managers consegue realmente abrir (o backend também
 * revalida isso em cada chamada, este guard é só a UX de redirecionar).
 */
export const managerGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);
  if (auth.isManager()) return true;
  router.navigate(['/servers']);
  return false;
};
