import { Routes } from '@angular/router';
import { authGuard } from './core/auth/auth.guard';
import { areaGuard } from './core/area/area.guard';
import { managerGuard } from './core/auth/manager.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./features/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'select-area',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./features/area-selector/area-selector.component').then((m) => m.AreaSelectorComponent),
  },
  {
    path: '',
    canActivate: [authGuard, areaGuard],
    loadComponent: () => import('./layout/shell.component').then((m) => m.ShellComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'servers' },
      {
        path: 'servers',
        loadComponent: () =>
          import('./features/servers/server-list.component').then((m) => m.ServerListComponent),
      },
      {
        path: 'servers/:hostId',
        loadComponent: () =>
          import('./features/servers/server-detail.component').then((m) => m.ServerDetailComponent),
      },
      {
        path: 'maintenance',
        loadComponent: () =>
          import('./features/maintenance/maintenance-list.component').then((m) => m.MaintenanceListComponent),
      },
      {
        path: 'items-triggers',
        loadComponent: () =>
          import('./features/items-triggers/items-triggers.component').then((m) => m.ItemsTriggersComponent),
      },
    ],
  },
  {
    // Rota OCULTA de gestão de áreas — de propósito fora do shell/menu.
    // Só acessível digitando a URL, e só funciona pra quem é portal manager
    // (managerGuard aqui + o backend revalida em /api/manage/**).
    path: 'portal-admin/areas',
    canActivate: [authGuard, managerGuard],
    loadComponent: () =>
      import('./features/manage-areas/manage-areas.component').then((m) => m.ManageAreasComponent),
  },
  { path: '**', redirectTo: 'login' },
];
