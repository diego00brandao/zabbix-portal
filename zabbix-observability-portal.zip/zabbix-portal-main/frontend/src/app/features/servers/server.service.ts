import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ServerDetail, ServerListItem } from './server.models';

@Injectable({ providedIn: 'root' })
export class ServerService {
  constructor(private http: HttpClient) {}

  list(): Observable<ServerListItem[]> {
    return this.http.get<ServerListItem[]>('/api/servers');
  }

  detail(hostId: string): Observable<ServerDetail> {
    return this.http.get<ServerDetail>(`/api/servers/${hostId}`);
  }
}
