import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ServerService } from './server.service';
import { ServerDetail } from './server.models';

const SEVERITY_CLASS: Record<string, string> = {
  '0': 'badge-info', '1': 'badge-info', '2': 'badge-warning', '3': 'badge-average', '4': 'badge-high', '5': 'badge-disaster',
};
const SEVERITY_LABEL: Record<string, string> = {
  '0': 'N/C', '1': 'INFO', '2': 'WARNING', '3': 'AVERAGE', '4': 'HIGH', '5': 'DISASTER',
};

type Tab = 'items' | 'triggers' | 'alerts';

@Component({
  selector: 'app-server-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './server-detail.component.html',
  styleUrl: './server-detail.component.css',
})
export class ServerDetailComponent implements OnInit {
  detail = signal<ServerDetail | null>(null);
  loading = signal(true);
  error = signal<string | null>(null);
  tab = signal<Tab>('alerts');

  constructor(private route: ActivatedRoute, private serverService: ServerService) {}

  ngOnInit(): void {
    const hostId = this.route.snapshot.paramMap.get('hostId')!;
    this.serverService.detail(hostId).subscribe({
      next: (d) => {
        this.detail.set(d);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(err.error?.error ?? 'Erro ao carregar detalhes do servidor');
        this.loading.set(false);
      },
    });
  }

  severityClass(sev: string): string { return SEVERITY_CLASS[sev] ?? 'badge-info'; }
  severityLabel(sev: string): string { return SEVERITY_LABEL[sev] ?? sev; }
}
