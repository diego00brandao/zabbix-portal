import { Component, OnInit, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ServerService } from './server.service';
import { ServerListItem } from './server.models';

const SEVERITY_CLASS: Record<number, string> = {
  0: 'badge-info', 1: 'badge-info', 2: 'badge-warning', 3: 'badge-average', 4: 'badge-high', 5: 'badge-disaster',
};
const SEVERITY_LABEL: Record<number, string> = {
  0: 'N/C', 1: 'INFO', 2: 'WARNING', 3: 'AVERAGE', 4: 'HIGH', 5: 'DISASTER',
};

@Component({
  selector: 'app-server-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './server-list.component.html',
  styleUrl: './server-list.component.css',
})
export class ServerListComponent implements OnInit {
  servers = signal<ServerListItem[]>([]);
  loading = signal(true);
  error = signal<string | null>(null);
  search = signal('');

  filtered = computed(() => {
    const q = this.search().toLowerCase().trim();
    const list = this.servers();
    if (!q) return list;
    return list.filter(
      (s) =>
        s.name?.toLowerCase().includes(q) ||
        s.host?.toLowerCase().includes(q) ||
        s.groups?.some((g) => g.name?.toLowerCase().includes(q)) ||
        s.parentTemplates?.some((t) => t.name?.toLowerCase().includes(q))
    );
  });

  constructor(private serverService: ServerService) {}

  ngOnInit(): void {
    this.serverService.list().subscribe({
      next: (servers) => {
        this.servers.set(servers);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(err.error?.error ?? 'Erro ao carregar servidores');
        this.loading.set(false);
      },
    });
  }

  severityClass(sev: number): string { return SEVERITY_CLASS[sev] ?? 'badge-info'; }
  severityLabel(sev: number): string { return SEVERITY_LABEL[sev] ?? '—'; }
}
