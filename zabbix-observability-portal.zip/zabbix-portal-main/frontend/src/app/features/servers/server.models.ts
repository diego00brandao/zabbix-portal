export interface ServerGroup { groupid: string; name: string; }
export interface ServerTemplate { templateid: string; name: string; }
export interface ServerInterface { ip: string; dns: string; type: string; available?: string; }

export interface ServerListItem {
  hostid: string;
  host: string;
  name: string;
  status: string;
  available: string;
  description?: string;
  groups?: ServerGroup[];
  interfaces?: ServerInterface[];
  parentTemplates?: ServerTemplate[];
  activeAlerts: number;
  maxSeverity: number;
}

export interface ServerItem {
  itemid: string;
  name: string;
  key_: string;
  type: string;
  typeLabel: string;
  delayFormatted: string;
  units?: string;
  lastvalue?: string;
  lastclock?: string;
  status: string;
  description?: string;
  error?: string;
  isQuery: boolean;
}

export interface ServerTrigger {
  triggerid: string;
  description: string;
  priority: string;
  status: string;
  expression: string;
  lastchange?: string;
  comments?: string;
}

export interface ServerDetail {
  host: {
    hostid: string;
    host: string;
    name: string;
    status: string;
    available: string;
    description?: string;
    groups?: ServerGroup[];
    interfaces?: ServerInterface[];
    parentTemplates?: ServerTemplate[];
  };
  summary: {
    totalItems: number;
    itemsActive: number;
    itemsDisabled: number;
    itemsQuery: number;
    totalTriggers: number;
    triggersActive: number;
    triggersDisabled: number;
    activeAlerts: number;
  };
  items: ServerItem[];
  triggers: ServerTrigger[];
  alerts: ServerTrigger[];
  generatedAt: string;
}
