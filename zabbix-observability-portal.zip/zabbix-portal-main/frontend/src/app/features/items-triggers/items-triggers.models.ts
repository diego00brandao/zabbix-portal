export interface ItHost { hostid: string; host: string; name: string; }

export interface ItItem {
  itemid: string;
  name: string;
  key_: string;
  type: string;
  params?: string;
  hosts?: ItHost[];
  isPrototype?: boolean;
}

export interface ItTrigger {
  triggerid: string;
  description: string;
  priority: string;
  status: string;
  expression: string;
  value?: string;
  hosts?: ItHost[];
  isPrototype?: boolean;
}
