import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Observable } from 'rxjs';
import { ItItem, ItTrigger } from './items-triggers.models';

@Injectable({ providedIn: 'root' })
export class ItemsTriggersService {
  constructor(private http: HttpClient) {}

  loadAll(): Observable<{ items: ItItem[]; triggers: ItTrigger[] }> {
    return forkJoin({
      items: this.http.get<ItItem[]>('/api/items'),
      triggers: this.http.get<ItTrigger[]>('/api/triggers'),
    });
  }
}
