import { Component, OnInit, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ItemsTriggersService } from './items-triggers.service';
import { ItItem, ItTrigger } from './items-triggers.models';

const SEVERITY_LABEL: Record<string, string> = {
  '0': 'N/C', '1': 'INFO', '2': 'WARNING', '3': 'AVERAGE', '4': 'HIGH', '5': 'DISASTER',
};
const SEVERITY_CLASS: Record<string, string> = {
  '0': 'badge-info', '1': 'badge-info', '2': 'badge-warning', '3': 'badge-average', '4': 'badge-high', '5': 'badge-disaster',
};

type FilterKey = 'all' | 'with-triggers';

interface TemplateGroup {
  template: string;
  items: ItItem[];
}

@Component({
  selector: 'app-items-triggers',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './items-triggers.component.html',
  styleUrl: './items-triggers.component.css',
})
export class ItemsTriggersComponent implements OnInit {
  items = signal<ItItem[]>([]);
  triggers = signal<ItTrigger[]>([]);
  loading = signal(true);
  error = signal<string | null>(null);
  search = signal('');
  activeFilter = signal<FilterKey>('all');
  expandedTemplates = signal<Record<string, boolean>>({});
  expandedItems = signal<Record<string, boolean>>({});

  constructor(private service: ItemsTriggersService) {}

  ngOnInit(): void {
    this.service.loadAll().subscribe({
      next: ({ items, triggers }) => {
        this.items.set(items);
        this.triggers.set(triggers);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(err.error?.error ?? 'Erro ao carregar itens e triggers');
        this.loading.set(false);
      },
    });
  }

  /** Extrai o primeiro parâmetro entre colchetes da chave (ex: "job_exec_30min" de "db.odbc.select[job_exec_30min,...]"). */
  private firstKeyParam(key: string): string | null {
    if (!key || !key.includes('[')) return null;
    return key.split('[')[1]?.split(',')[0]?.split(']')[0] ?? null;
  }

  linkedTriggers(item: ItItem): ItTrigger[] {
    const key = item.key_;
    if (!key) return [];
    const firstParam = this.firstKeyParam(key);
    return this.triggers().filter((t) => {
      const expr = t.expression || '';
      if (expr.includes(`/${key}]`) || expr.includes(`/${key},`) || expr.includes(`/${key}"`)) return true;
      if (firstParam && firstParam.length > 4 && expr.includes(`[${firstParam},`)) return true;
      return false;
    });
  }

  hasLinkedTrigger(item: ItItem): boolean {
    return this.linkedTriggers(item).length > 0;
  }

  private groupedByTemplate = computed<Record<string, ItItem[]>>(() => {
    const map: Record<string, ItItem[]> = {};
    for (const item of this.items()) {
      const tpl = item.hosts?.[0]?.name || 'Sem Template';
      (map[tpl] ??= []).push(item);
    }
    return map;
  });

  private filterItems(items: ItItem[]): ItItem[] {
    const q = this.search().toLowerCase();
    let result = items;
    if (this.activeFilter() === 'with-triggers') {
      result = result.filter((i) => this.hasLinkedTrigger(i));
    }
    if (!q) return result;
    return result.filter(
      (i) =>
        i.name?.toLowerCase().includes(q) ||
        i.key_?.toLowerCase().includes(q) ||
        this.linkedTriggers(i).some((t) => t.description?.toLowerCase().includes(q))
    );
  }

  templateGroups = computed<TemplateGroup[]>(() => {
    const grouped = this.groupedByTemplate();
    const q = this.search().toLowerCase();
    return Object.keys(grouped)
      .filter((tpl) => {
        const tplItems = this.filterItems(grouped[tpl]);
        if (tplItems.length === 0) return false;
        if (!q) return true;
        if (tpl.toLowerCase().includes(q)) return true;
        return tplItems.some(
          (i) =>
            i.name?.toLowerCase().includes(q) ||
            i.key_?.toLowerCase().includes(q) ||
            this.linkedTriggers(i).some((t) => t.description?.toLowerCase().includes(q))
        );
      })
      .sort()
      .map((tpl) => ({ template: tpl, items: this.filterItems(grouped[tpl]) }));
  });

  totalTemplates = computed(() => Object.keys(this.groupedByTemplate()).length);

  isTemplateOpen(tpl: string): boolean {
    return this.expandedTemplates()[tpl] !== false;
  }

  toggleTemplate(tpl: string): void {
    this.expandedTemplates.update((e) => ({ ...e, [tpl]: this.isTemplateOpen(tpl) ? false : true }));
  }

  isItemOpen(itemId: string): boolean {
    return !!this.expandedItems()[itemId];
  }

  toggleItem(itemId: string): void {
    this.expandedItems.update((e) => ({ ...e, [itemId]: !e[itemId] }));
  }

  severityLabel(p: string): string { return SEVERITY_LABEL[p] ?? p; }
  severityClass(p: string): string { return SEVERITY_CLASS[p] ?? 'badge-info'; }
}
