import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  AreaAdmin,
  AreaUpsertRequest,
  PortalManager,
  ZabbixConnection,
  ZabbixConnectionUpsertRequest,
} from './manage.models';

/** Tudo aqui é a tela oculta (/api/manage/**) — só responde para portal managers. */
@Injectable({ providedIn: 'root' })
export class ManageService {
  constructor(private http: HttpClient) {}

  listAreas(): Observable<AreaAdmin[]> {
    return this.http.get<AreaAdmin[]>('/api/manage/areas');
  }
  createArea(req: AreaUpsertRequest): Observable<AreaAdmin> {
    return this.http.post<AreaAdmin>('/api/manage/areas', req);
  }
  updateArea(id: number, req: AreaUpsertRequest): Observable<AreaAdmin> {
    return this.http.put<AreaAdmin>(`/api/manage/areas/${id}`, req);
  }
  deleteArea(id: number): Observable<unknown> {
    return this.http.delete(`/api/manage/areas/${id}`);
  }

  listConnections(): Observable<ZabbixConnection[]> {
    return this.http.get<ZabbixConnection[]>('/api/manage/zabbix-connections');
  }
  createConnection(req: ZabbixConnectionUpsertRequest): Observable<ZabbixConnection> {
    return this.http.post<ZabbixConnection>('/api/manage/zabbix-connections', req);
  }
  updateConnection(id: number, req: ZabbixConnectionUpsertRequest): Observable<ZabbixConnection> {
    return this.http.put<ZabbixConnection>(`/api/manage/zabbix-connections/${id}`, req);
  }
  deleteConnection(id: number): Observable<unknown> {
    return this.http.delete(`/api/manage/zabbix-connections/${id}`);
  }
  activateConnection(id: number): Observable<unknown> {
    return this.http.post(`/api/manage/zabbix-connections/${id}/activate`, {});
  }
  testConnection(req: ZabbixConnectionUpsertRequest): Observable<{ success: boolean; version?: string; error?: string }> {
    return this.http.post<{ success: boolean; version?: string; error?: string }>('/api/manage/zabbix-connections/test', req);
  }

  listManagers(): Observable<PortalManager[]> {
    return this.http.get<PortalManager[]>('/api/manage/managers');
  }
  addManager(username: string): Observable<PortalManager> {
    return this.http.post<PortalManager>('/api/manage/managers', { username });
  }
  removeManager(id: number): Observable<unknown> {
    return this.http.delete(`/api/manage/managers/${id}`);
  }
}
