import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ManageService } from './manage.service';
import {
  AreaAdmin,
  AreaUpsertRequest,
  FilterType,
  PortalManager,
  ZabbixAuthType,
  ZabbixConnection,
  ZabbixConnectionUpsertRequest,
} from './manage.models';
import { AuthService } from '../../core/auth/auth.service';

function emptyAreaForm(): AreaUpsertRequest {
  return { name: '', description: '', color: '#3B82F6', filterType: 'HOST_GROUP',
    groupNames: '', tagKey: '', tagValue: '', zabbixConnectionId: null };
}

function emptyConnForm(): ZabbixConnectionUpsertRequest {
  return { name: '', url: '', authType: 'TOKEN', token: '', username: '', password: '' };
}

type Tab = 'areas' | 'connections' | 'managers';

/**
 * Tela OCULTA de gestão — não tem link em nenhum menu do usuário final (só
 * quem gerencia o portal chega aqui, via URL direta: /portal-admin/areas).
 * É aqui que se cadastra área nova e se escolhe, por área, se a condição é
 * por GRUPO ou por TAG — nunca fixo no código.
 *
 * Nota: areaForm/connForm são propriedades simples (não signals) de
 * propósito — são só estado de formulário local, e o Angular template
 * parser não aceita arrow functions (`f => ({...f, x: $event})`), então
 * [(ngModel)] direto em objeto mutável é o jeito mais simples aqui.
 */
@Component({
  selector: 'app-manage-areas',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-areas.component.html',
  styleUrl: './manage-areas.component.css',
})
export class ManageAreasComponent implements OnInit {
  tab = signal<Tab>('areas');

  // Áreas
  areas = signal<AreaAdmin[]>([]);
  areaForm: AreaUpsertRequest = emptyAreaForm();
  editingAreaId = signal<number | null>(null);
  areaError = signal<string | null>(null);
  areaSaving = signal(false);

  // Conexões Zabbix
  connections = signal<ZabbixConnection[]>([]);
  connForm: ZabbixConnectionUpsertRequest = emptyConnForm();
  editingConnId = signal<number | null>(null);
  connError = signal<string | null>(null);
  connTestResult = signal<string | null>(null);
  connSaving = signal(false);

  // Gestores do portal
  managers = signal<PortalManager[]>([]);
  newManagerUsername = '';
  managerError = signal<string | null>(null);

  loading = signal(true);

  constructor(private manage: ManageService, private router: Router, public auth: AuthService) {}

  ngOnInit(): void {
    this.reloadAll();
  }

  private reloadAll(): void {
    this.loading.set(true);
    this.manage.listAreas().subscribe((areas) => this.areas.set(areas));
    this.manage.listConnections().subscribe((conns) => {
      this.connections.set(conns);
      this.loading.set(false);
    });
    this.manage.listManagers().subscribe((m) => this.managers.set(m));
  }

  backToPortal(): void {
    this.router.navigate(['/servers']);
  }

  // ── Áreas ────────────────────────────────────────────────────────────
  setFilterType(type: FilterType): void {
    this.areaForm.filterType = type;
  }

  editArea(area: AreaAdmin): void {
    this.editingAreaId.set(area.id);
    this.areaForm = {
      name: area.name, description: area.description, color: area.color, filterType: area.filterType,
      groupNames: area.groupNames, tagKey: area.tagKey, tagValue: area.tagValue,
      zabbixConnectionId: area.zabbixConnectionId,
    };
  }

  newArea(): void {
    this.editingAreaId.set(null);
    this.areaForm = emptyAreaForm();
    this.areaError.set(null);
  }

  saveArea(): void {
    this.areaError.set(null);
    this.areaSaving.set(true);
    const req = this.areaForm;
    const obs = this.editingAreaId()
      ? this.manage.updateArea(this.editingAreaId()!, req)
      : this.manage.createArea(req);
    obs.subscribe({
      next: () => {
        this.areaSaving.set(false);
        this.newArea();
        this.manage.listAreas().subscribe((areas) => this.areas.set(areas));
      },
      error: (err) => {
        this.areaSaving.set(false);
        this.areaError.set(err.error?.error ?? 'Erro ao salvar área');
      },
    });
  }

  deleteArea(area: AreaAdmin): void {
    if (!confirm(`Excluir a área "${area.name}"?`)) return;
    this.manage.deleteArea(area.id).subscribe(() => {
      this.manage.listAreas().subscribe((areas) => this.areas.set(areas));
    });
  }

  connectionName(id: number | null): string {
    if (!id) return 'Conexão ativa padrão';
    return this.connections().find((c) => c.id === id)?.name ?? `#${id}`;
  }

  // ── Conexões Zabbix ─────────────────────────────────────────────────
  editConnection(conn: ZabbixConnection): void {
    this.editingConnId.set(conn.id);
    this.connForm = {
      name: conn.name, url: conn.url, authType: conn.authType, token: '', username: conn.username, password: '',
    };
    this.connTestResult.set(null);
  }

  newConnection(): void {
    this.editingConnId.set(null);
    this.connForm = emptyConnForm();
    this.connError.set(null);
    this.connTestResult.set(null);
  }

  setAuthType(type: ZabbixAuthType): void {
    this.connForm.authType = type;
  }

  testConnection(): void {
    this.connTestResult.set('Testando...');
    this.manage.testConnection(this.connForm).subscribe((res) => {
      this.connTestResult.set(res.success ? `✓ Conectado (Zabbix ${res.version})` : `✗ ${res.error}`);
    });
  }

  saveConnection(): void {
    this.connError.set(null);
    this.connSaving.set(true);
    const req = this.connForm;
    const obs = this.editingConnId()
      ? this.manage.updateConnection(this.editingConnId()!, req)
      : this.manage.createConnection(req);
    obs.subscribe({
      next: () => {
        this.connSaving.set(false);
        this.newConnection();
        this.manage.listConnections().subscribe((c) => this.connections.set(c));
      },
      error: (err) => {
        this.connSaving.set(false);
        this.connError.set(err.error?.error ?? 'Erro ao salvar conexão');
      },
    });
  }

  activateConnection(conn: ZabbixConnection): void {
    this.manage.activateConnection(conn.id).subscribe(() => {
      this.manage.listConnections().subscribe((c) => this.connections.set(c));
    });
  }

  deleteConnection(conn: ZabbixConnection): void {
    if (!confirm(`Excluir a conexão "${conn.name}"?`)) return;
    this.manage.deleteConnection(conn.id).subscribe(() => {
      this.manage.listConnections().subscribe((c) => this.connections.set(c));
    });
  }

  // ── Gestores ────────────────────────────────────────────────────────
  addManager(): void {
    this.managerError.set(null);
    if (!this.newManagerUsername.trim()) return;
    this.manage.addManager(this.newManagerUsername.trim()).subscribe({
      next: () => {
        this.newManagerUsername = '';
        this.manage.listManagers().subscribe((m) => this.managers.set(m));
      },
      error: (err) => this.managerError.set(err.error?.error ?? 'Erro ao adicionar gestor'),
    });
  }

  removeManager(m: PortalManager): void {
    if (!confirm(`Remover acesso de gestor de "${m.username}"?`)) return;
    this.manage.removeManager(m.id).subscribe({
      next: () => this.manage.listManagers().subscribe((list) => this.managers.set(list)),
      error: (err) => this.managerError.set(err.error?.error ?? 'Erro ao remover gestor'),
    });
  }
}
