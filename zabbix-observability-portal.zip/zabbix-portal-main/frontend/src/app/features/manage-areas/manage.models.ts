export type FilterType = 'HOST_GROUP' | 'TAG';

export interface AreaAdmin {
  id: number;
  name: string;
  description: string | null;
  color: string;
  filterType: FilterType;
  groupNames: string | null;
  tagKey: string | null;
  tagValue: string | null;
  zabbixConnectionId: number | null;
}

export interface AreaUpsertRequest {
  name: string;
  description: string | null;
  color: string;
  filterType: FilterType;
  groupNames: string | null;
  tagKey: string | null;
  tagValue: string | null;
  zabbixConnectionId: number | null;
}

export type ZabbixAuthType = 'TOKEN' | 'USERPASS';

export interface ZabbixConnection {
  id: number;
  name: string;
  url: string;
  authType: ZabbixAuthType;
  username: string | null;
  active: boolean;
}

export interface ZabbixConnectionUpsertRequest {
  name: string;
  url: string;
  authType: ZabbixAuthType;
  token: string | null;
  username: string | null;
  password: string | null;
}

export interface PortalManager {
  id: number;
  username: string;
  addedBy: string | null;
}
