import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { environment } from '../../../environments/environment';

/**
 * Login duplo: Blackbird é o método PRINCIPAL — se estiver habilitado, o
 * botão fica em destaque. O formulário local abaixo NUNCA fica escondido:
 * é o fallback para quando o Blackbird está fora do ar.
 */
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent implements OnInit {
  blackbirdEnabled = signal(false);
  blackbirdChecking = signal(true);
  blackbirdError = signal<string | null>(null);

  username = '';
  password = '';
  localLoading = signal(false);
  localError = signal<string | null>(null);

  constructor(private auth: AuthService, private router: Router, private route: ActivatedRoute) {}

  ngOnInit(): void {
    // Se o Blackbird redirecionou de volta com um token, completa o login automaticamente.
    const bbToken = this.route.snapshot.queryParamMap.get('bb_token');
    if (bbToken) {
      this.auth.loginBlackbird(bbToken).subscribe({
        next: () => this.router.navigate(['/select-area']),
        error: (err) => this.blackbirdError.set(err.error?.error ?? 'Falha ao entrar com o Blackbird'),
      });
    }

    this.auth.config().subscribe({
      next: (cfg) => {
        this.blackbirdEnabled.set(cfg.blackbirdEnabled);
        this.blackbirdChecking.set(false);
      },
      error: () => this.blackbirdChecking.set(false),
    });
  }

  get blackbirdLoginUrl(): string {
    return environment.blackbirdLoginUrl;
  }

  goToBlackbird(): void {
    window.location.href = this.blackbirdLoginUrl;
  }

  submitLocal(): void {
    this.localError.set(null);
    this.localLoading.set(true);
    this.auth.login(this.username, this.password).subscribe({
      next: () => {
        this.localLoading.set(false);
        this.router.navigate(['/select-area']);
      },
      error: (err) => {
        this.localLoading.set(false);
        this.localError.set(err.error?.error ?? 'Não foi possível entrar');
      },
    });
  }
}
