import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AreaService } from '../../core/area/area.service';
import { AreaPublic } from '../../core/area/area.models';
import { AuthService } from '../../core/auth/auth.service';

@Component({
  selector: 'app-area-selector',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './area-selector.component.html',
  styleUrl: './area-selector.component.css',
})
export class AreaSelectorComponent implements OnInit {
  areas = signal<AreaPublic[]>([]);
  loading = signal(true);
  error = signal<string | null>(null);

  constructor(private areaService: AreaService, private auth: AuthService, private router: Router) {}

  ngOnInit(): void {
    this.areaService.list().subscribe({
      next: (areas) => {
        this.areas.set(areas);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Não foi possível carregar as áreas');
        this.loading.set(false);
      },
    });
  }

  choose(area: AreaPublic): void {
    this.areaService.select(area);
    this.router.navigate(['/servers']);
  }

  logout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
