import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Maintenance } from './maintenance.models';

@Injectable({ providedIn: 'root' })
export class MaintenanceService {
  constructor(private http: HttpClient) {}

  list(): Observable<Maintenance[]> {
    return this.http.get<Maintenance[]>('/api/maintenances');
  }
}
