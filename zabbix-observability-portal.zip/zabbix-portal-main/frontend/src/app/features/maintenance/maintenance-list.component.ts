import { Component, OnInit, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MaintenanceService } from './maintenance.service';
import { Maintenance } from './maintenance.models';

interface Status { label: string; cssClass: string; }

@Component({
  selector: 'app-maintenance-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './maintenance-list.component.html',
  styleUrl: './maintenance-list.component.css',
})
export class MaintenanceListComponent implements OnInit {
  maintenances = signal<Maintenance[]>([]);
  loading = signal(true);
  error = signal<string | null>(null);
  filter = signal('');

  filtered = computed(() => {
    const q = this.filter().toLowerCase().trim();
    const list = this.maintenances();
    if (!q) return list;
    return list.filter(
      (m) =>
        m.name?.toLowerCase().includes(q) ||
        m.hosts?.some((h) => h.name?.toLowerCase().includes(q) || h.host?.toLowerCase().includes(q)) ||
        m.groups?.some((g) => g.name?.toLowerCase().includes(q))
    );
  });

  constructor(private maintenanceService: MaintenanceService) {}

  ngOnInit(): void {
    this.maintenanceService.list().subscribe({
      next: (list) => {
        this.maintenances.set(list);
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(err.error?.error ?? 'Erro ao carregar manutenções');
        this.loading.set(false);
      },
    });
  }

  status(m: Maintenance): Status {
    const now = Math.floor(Date.now() / 1000);
    const since = parseInt(m.active_since, 10);
    const till = parseInt(m.active_till, 10);
    if (now >= since && now <= till) return { label: 'Ativa', cssClass: 'badge-ok' };
    if (now < since) return { label: 'Agendada', cssClass: 'badge-warning' };
    return { label: 'Encerrada', cssClass: 'badge-info' };
  }

  fmtDate(ts: string): string {
    if (!ts || ts === '0') return '—';
    return new Date(parseInt(ts, 10) * 1000).toLocaleString('pt-BR');
  }

  timeRemaining(m: Maintenance): string | null {
    const now = Math.floor(Date.now() / 1000);
    const since = parseInt(m.active_since, 10);
    const till = parseInt(m.active_till, 10);
    const ref = now >= since && now <= till ? till : now < since ? since : null;
    if (!ref) return null;
    const diff = ref - now;
    if (diff <= 0) return null;
    const days = Math.floor(diff / 86400);
    const hours = Math.floor((diff % 86400) / 3600);
    const mins = Math.floor((diff % 3600) / 60);
    const label = now >= since ? 'Expira em' : 'Inicia em';
    if (days > 0) return `${label}: ${days}d ${hours}h`;
    if (hours > 0) return `${label}: ${hours}h ${mins}min`;
    return `${label}: ${mins}min`;
  }
}
