export interface MaintenanceHost { hostid: string; host: string; name: string; }
export interface MaintenanceGroup { groupid: string; name: string; }

export interface Maintenance {
  maintenanceid: string;
  name: string;
  description?: string;
  active_since: string;
  active_till: string;
  hosts?: MaintenanceHost[];
  groups?: MaintenanceGroup[];
}
