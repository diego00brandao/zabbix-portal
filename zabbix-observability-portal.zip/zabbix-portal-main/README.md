# Observability Portal

Portal web de observabilidade sobre o Zabbix. Reescrito em **Angular** (frontend) e **Java / Spring Boot**
(backend) para se integrar ao **Blackbird**: cada área faz login no Blackbird, abre o Portal Observability
e escolhe a área que quer ver (Banco de Dados, Network, ...). Quais servidores/templates pertencem a cada
área é configurável — por grupo do Zabbix ou por tag (ex: `portal:dba`) — na tela oculta de gestão, nunca
fixo no código.

> O código anterior (React + Node/Express + SQLite) fica em [`legacy/`](legacy/) só como referência —
> não é mais mantido.

## Stack

- **Backend:** Java 21 + Spring Boot 3 + Maven, banco H2 embarcado (arquivo), Flyway
- **Frontend:** Angular 18 (standalone components)
- **Proxy:** Nginx
- **API externa:** Zabbix via JSON-RPC

## Escopo

Só 3 telas, para quem já escolheu sua área:

- **Servidores** — lista + detalhe (itens, triggers, alertas, resumo)
- **Manutenções** — janelas de manutenção cadastradas no Zabbix (somente leitura)
- **Itens & Triggers** — visão relacional agrupada por template

Não tem mais tela de Admin para o usuário final. Quem cadastra áreas novas e escolhe a condição
(grupo ou tag) de cada uma é feito numa tela **oculta** (`/portal-admin/areas`, sem link em nenhum
menu), restrita a quem está na lista de gestores do portal.

Autenticação é dupla: **Blackbird** é o método principal; se o Blackbird estiver fora do ar, o portal
cai automaticamente para o login local (usuário/senha, igual ao portal anterior).

## Setup

### Docker (recomendado)

```bash
cp .env.example .env
# edita o .env — pelo menos PORTAL_JWT_SECRET
docker compose up -d --build
# acessa http://localhost:8080/portal/
# login local padrão: admin / Admin@2024!
```

### Manual (desenvolvimento)

```bash
# Backend
cd backend
mvn spring-boot:run   # porta 3001

# Frontend (outro terminal)
cd frontend
npm install
npm start              # ng serve, porta 4200, com proxy /api -> localhost:3001
```

### ⚠️ Se você está retomando este projeto de uma sessão do Claude

O ambiente onde este backend foi escrito **não tinha acesso ao Maven Central** (bloqueado pela política
de rede do sandbox), então o Java **nunca foi compilado nem testado** ali — só revisado manualmente com
bastante cuidado. O frontend Angular, por outro lado, **foi buildado com sucesso** (`ng build` passou,
incluindo a correção de alguns erros de sintaxe de template do Angular 18).

Antes de considerar o backend pronto, rode, num ambiente com internet:

```bash
cd backend
mvn clean package        # baixa as dependências e compila
mvn test                 # roda os testes de AreaScopeResolver (grupo vs tag) com WireMock
```

Erros mais prováveis de aparecer num primeiro build: nomes de dependência/versão do Maven Central que
não bati 100% de cabeça (ex: coordenadas exatas do WireMock 3.x), e o operador `1` (Equals) usado no
filtro `tags` da API do Zabbix em `AreaScopeResolver.java` — comparar com a documentação da versão
exata do Zabbix em produção antes de ir pra produção.

O `pom.xml` está em Java 21 (não 17) porque `ZabbixScope.java` usa `switch` com pattern matching sobre
uma sealed interface (`case GroupScope g -> ...`), recurso finalizado só a partir do Java 21 — o
`Dockerfile` já usa as imagens `maven:3.9-eclipse-temurin-21` / `eclipse-temurin:21-jre-jammy`
correspondentes.

## Configurar a condição de cada área (grupo ou tag)

Acesse `/portal-admin/areas` logado como alguém da lista de gestores (`PORTAL_MANAGER_USERNAMES` no
`.env`, ou adicionado depois pela própria tela). Lá dá para:

- Criar uma área nova (o pedido original já vem com duas: **Banco de Dados** por grupo, **Network** por tag)
- Escolher, por área, se a condição é por **grupo** (nome do host group / template group no Zabbix) ou
  por **tag** (chave+valor, ex: `portal:dba`) — quem escolhe é você, não o código
- Configurar qual conexão Zabbix (URL + autenticação) cada área usa

Se a condição for por tag, marque os hosts **e** os templates dessa área com a tag no Zabbix.

## Integração com o Blackbird

Ainda não temos o contrato final do Blackbird, então `BlackbirdAuthService.java` (backend) fica isolado
atrás de uma validação de JWT por segredo compartilhado (HMAC) — configurável via `BLACKBIRD_*` no
`.env`. Quando o time do Blackbird definir o formato real (redirect OAuth2/OIDC, outro claim set etc.),
só esse arquivo precisa mudar. Enquanto `BLACKBIRD_AUTH_ENABLED=false`, o portal usa só o login local.

## Testando sem um Zabbix real

`docs/dev-tools/fake_zabbix.py` sobe um Zabbix "fake" com dados de exemplo já marcados por grupo e por
tag — útil para validar rapidamente que as duas condições retornam os dados certos antes de plugar no
Zabbix de produção:

```bash
python3 docs/dev-tools/fake_zabbix.py 9091
# cadastra uma ZabbixConnection apontando pra http://localhost:9091/api_jsonrpc.php (auth: token, qualquer valor)
```

## Fora de escopo

Dashboard, Alertas (tela solta), Change Log, Relatórios, Alfred IA, Ferramentas, Audit Log, Grupos,
tela de Conexões separada (virou parte da gestão de áreas) — tudo isso existia no portal anterior
(`legacy/`) e foi removido de propósito conforme o novo escopo (só Servidores, Manutenções e
Itens & Triggers).
