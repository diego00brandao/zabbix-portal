#!/usr/bin/env python3
"""
Zabbix "fake" para testar localmente as duas condições de área (grupo e tag)
sem precisar de um Zabbix real. Sobe um servidor JSON-RPC mínimo com dados de
exemplo já marcados com:
  - host group "Banco de Dados" (id 10) -> host "db01" + template "Oracle"
  - tag portal:network                  -> host "sw01" + template "Switches"

Uso:
    python3 fake_zabbix.py [porta]      # padrão: 9091

Depois, configure uma ZabbixConnection na tela de gestão (/portal-admin/areas)
apontando para http://localhost:<porta>/api_jsonrpc.php, auth_type=TOKEN,
token=qualquer-coisa (esse fake não valida o token).

Isso NÃO substitui testar contra um Zabbix real antes de ir para produção —
serve só para validar rapidamente que a condição por grupo e a condição por
tag chegam nos dados certos.
"""
import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 9091

HOSTGROUPS = [{"groupid": "10", "name": "Banco de Dados"}]

HOSTS = [
    {
        "hostid": "100", "host": "db01", "name": "db01.exemplo.com", "status": "0", "available": "1",
        "description": "Servidor Oracle de exemplo",
        "groups": [{"groupid": "10", "name": "Banco de Dados"}],
        "interfaces": [{"ip": "10.0.0.10", "dns": "", "type": "1", "available": "1"}],
        "parentTemplates": [{"templateid": "200", "name": "Oracle DB"}],
        "triggers": [{"triggerid": "900", "priority": "3", "value": "1"}],
        "tags": [],
    },
    {
        "hostid": "101", "host": "sw01", "name": "sw01.exemplo.com", "status": "0", "available": "1",
        "description": "Switch de exemplo",
        "groups": [],
        "interfaces": [{"ip": "10.0.0.20", "dns": "", "type": "2", "available": "1"}],
        "parentTemplates": [{"templateid": "201", "name": "Switches Genéricos"}],
        "triggers": [],
        "tags": [{"tag": "portal", "value": "network"}],
    },
]

TEMPLATES = [
    {"templateid": "200", "host": "Oracle DB", "name": "Oracle DB", "tags": []},
    {"templateid": "201", "host": "Switches Genéricos", "name": "Switches Genéricos", "tags": [{"tag": "portal", "value": "network"}]},
]

ITEMS = [
    {"itemid": "300", "name": "CPU Usage", "key_": "system.cpu.util", "type": "0", "delay": "60s",
     "status": "0", "templateid": "200"},
    {"itemid": "301", "name": "Interface Errors", "key_": "net.if.errors", "type": "0", "delay": "60s",
     "status": "0", "templateid": "201"},
]

TRIGGERS = [
    {"triggerid": "900", "description": "CPU acima de 90%", "priority": "3", "status": "0",
     "expression": "last(/db01/system.cpu.util)>90", "value": "1", "templateid": "200"},
    {"triggerid": "901", "description": "Erros de rede detectados", "priority": "4", "status": "0",
     "expression": "last(/sw01/net.if.errors)>0", "value": "0", "templateid": "201"},
]

MAINTENANCES = [
    {"maintenanceid": "500", "name": "Janela mensal - Banco de Dados", "description": "Patch mensal",
     "active_since": "1893456000", "active_till": "1893542400",
     "hosts": [{"hostid": "100", "host": "db01", "name": "db01.exemplo.com"}], "groups": []},
]


def filter_by_tags(objs, tags):
    if not tags:
        return objs
    wanted = {(t["tag"], t["value"]) for t in tags}
    return [o for o in objs if any((t["tag"], t["value"]) in wanted for t in o.get("tags", []))]


def filter_by_group(objs, groupids):
    if not groupids:
        return objs
    ids = set(groupids)
    return [o for o in objs if any(g["groupid"] in ids for g in o.get("groups", []))]


def handle(method, params):
    if method == "apiinfo.version":
        return "6.0.42"
    if method == "user.login":
        return "fake-session-token"
    if method == "hostgroup.get":
        names = (params.get("filter") or {}).get("name")
        result = HOSTGROUPS
        if names:
            result = [g for g in result if g["name"] in names]
        return result
    if method == "host.get":
        result = HOSTS
        if params.get("tags"):
            result = filter_by_tags(result, params["tags"])
        if params.get("groupids"):
            result = filter_by_group(result, params["groupids"])
        if params.get("hostids"):
            ids = set(params["hostids"])
            result = [h for h in result if h["hostid"] in ids]
        return result
    if method == "template.get":
        result = TEMPLATES
        if params.get("tags"):
            result = filter_by_tags(result, params["tags"])
        if params.get("templateids"):
            ids = set(params["templateids"])
            result = [t for t in result if t["templateid"] in ids]
        return result
    if method in ("item.get", "itemprototype.get"):
        if method == "itemprototype.get":
            return []
        result = ITEMS
        if params.get("templateids"):
            ids = set(params["templateids"])
            result = [i for i in result if i["templateid"] in ids]
        if params.get("hostids"):
            ids = set(params["hostids"])
            result = [i for i in result if i.get("hostid") in ids]
        return result
    if method in ("trigger.get", "triggerprototype.get"):
        if method == "triggerprototype.get":
            return []
        result = TRIGGERS
        if params.get("templateids"):
            ids = set(params["templateids"])
            result = [t for t in result if t["templateid"] in ids]
        if params.get("hostids"):
            ids = set(params["hostids"])
            result = [t for t in result if t.get("hostid") in ids]
        if (params.get("filter") or {}).get("value") == "1":
            result = [t for t in result if t.get("value") == "1"]
        return result
    if method == "maintenance.get":
        return MAINTENANCES
    return []


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length) or b"{}")
        method = body.get("method")
        params = body.get("params") or {}
        try:
            result = handle(method, params)
            payload = {"jsonrpc": "2.0", "result": result, "id": body.get("id", 1)}
        except Exception as e:  # pragma: no cover - só pro dev tool
            payload = {"jsonrpc": "2.0", "error": {"message": str(e)}, "id": body.get("id", 1)}
        data = json.dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        print(f"[fake-zabbix] {fmt % args}")


if __name__ == "__main__":
    print(f"Fake Zabbix rodando em http://localhost:{PORT}/api_jsonrpc.php")
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
